# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 14:45:03 2024

@author: scrouse6
"""

import numpy as np
from scipy.stats.qmc import LatinHypercube

n_species_solid = 4
n_experiments_solid = 16
n_species_liquid = 4
n_experiments_liquid = 16
seed = 19

sampler_solid = LatinHypercube(d = n_species_solid, scramble = False, seed = seed)
Y_solid_temp = sampler_solid.random(n = n_experiments_solid)
Y_solid = (Y_solid_temp - Y_solid_temp.min())/(Y_solid_temp.max()-Y_solid_temp.min())

sampler_liquid = LatinHypercube(d = n_species_liquid, scramble = False, seed = seed)
Y_liquid_temp = sampler_liquid.random(n = n_experiments_liquid)
Y_liquid = (Y_liquid_temp - Y_liquid_temp.min())/(Y_liquid_temp.max()-Y_liquid_temp.min())

def efficient_plan(Y):
    n_experiments = np.size(Y, axis=0)
    def exper_sort(Y):
        combined = []
        for i in range(np.size(Y, axis=0)):
            for j in range(np.size(Y, axis=0)-i-1):
                Y1 = Y[i,:]
                Y2 = Y[j+i+1,:]
                count = 0
                for k in range(np.size(Y, axis=1)):
                    if Y2[k] > Y1[k]:
                        count += 1
                if count == np.size(Y, axis=1):
                    combined = combined + [np.array([i,j+i+1])]
        return combined #[small, large]
    
    combined = exper_sort(Y)
    chosen_indices = []
    for i in reversed(range(np.size(combined, axis=0))):
        test_point1 = combined[i][0]
        test_point2 = combined[i][1]
        if np.isin(test_point1, chosen_indices)==False:
            if np.isin(test_point2, chosen_indices)==False:
                chosen_indices = chosen_indices + [combined[i]]
                
    new_indices = np.zeros((2*len(chosen_indices)))
    for i in range(len(chosen_indices)):
        new_indices[2*i] = chosen_indices[i][0]
        new_indices[2*i+1] = chosen_indices[i][1]
    
    remaining_indices = np.arange(n_experiments)
    remaining_indices = np.delete(remaining_indices, chosen_indices)
    
    n_actual_experiments = len(chosen_indices)
    Y_final = Y[np.hstack((new_indices, remaining_indices)).astype(int),:]
    return Y_final, n_actual_experiments

Y_solid_final, n_actual_experiments_solid = efficient_plan(Y_solid)
Y_liquid_final, n_actual_experiments_liquid = efficient_plan(Y_liquid)

print(str(n_experiments_solid) + ' solid experiments reduced to ' + str(n_experiments_solid - n_actual_experiments_solid) + ' experiments')
print(str(n_experiments_liquid) + ' liquid experiments reduced to ' + str(n_experiments_liquid - n_actual_experiments_liquid) + ' experiments')

