# -*- coding: utf-8 -*-
"""
Created on Thu Sep  5 16:48:54 2024

@author: scrouse6
"""

"""
Packages
"""
import numpy as np
import pandas as pd
import matplotlib as mpl
import pylab as plt
from matplotlib.lines import Line2D
from sklearn.model_selection import train_test_split as TTS
from sklearn.decomposition import PCA
from sklearn.cross_decomposition import PLSRegression as PLSR
from sklearn.linear_model import LinearRegression
from sklearn.decomposition import FastICA as ICA
from sklearn.metrics import r2_score as R2
from sklearn.metrics import mean_absolute_percentage_error as MAPE
from sklearn.metrics import root_mean_squared_error as RMSE
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.metrics.pairwise import rbf_kernel as RBF
from scipy.signal import savgol_filter
from pathlib import Path
from PIL import Image
from matplotlib.patches import Ellipse
import matplotlib.transforms as transforms
from scipy.stats import chi2
import seaborn as sns
from sklearn.metrics import confusion_matrix
import os, platform, io
from pathlib import Path
path = Path(__file__).resolve().parent

"""
User-Defined Functions
"""

from Functions import *

mpl.rcParams['font.family'] = 'Times New Roman'
plt.rcParams.update({'font.size': 20})
mpl.rcParams['figure.dpi'] = 300
color=['orangered','royalblue','goldenrod','chocolate','deeppink','limegreen','darkviolet','slategray','turquoise','dodgerblue','seagreen']
color0 = '#cfe0fa'
marker=['o','^','s','*','D','X','1','+','3','v']
linestyle = ['-', '--', ':', '-.', (0, (1,1)), (0, (3,1,1,1)), (0, (5,1)), (0, (5,5))]
title_list = ['a)','b)','c)','d)','e)','f)','g)','h)','i)','j)','k)']

save_folder_pdf = path / 'Figures/PDF/'
save_folder_jpg = path / 'Figures/JPG/'
save_folder_eps = path / 'Figures/EPS/'
save = True

directory = path / 'Raw Data/Training Data/'
directory_process = path / 'Raw Data/Process Data/'

species_l = ['Nitrate','Nitrite','Sulfate','Borate']
species_s = ['Iron Oxide','Kyanite','Silica','Gibbsite']

slurry_experiments = ['1-1','1-2','1-3','2-1','2-2','2-3','3-1','3-2','3-3',
                      '4-1','4-2','4-3','5-1','5-2','5-3','6-1','6-2','6-3',
                      '7-1','7-2','7-3','8-1','8-2','8-3','9-1','9-2','9-3',
                      '11-1','11-2','11-3','12-1','12-2','12-3','13-1','13-2','13-3']

"""
Loading Data
"""

file_npz = np.load(path / 'Fault Data Publication.npz', allow_pickle=True)
variable_order = ['X_process_ram', 'X_process_ir', 'X_process_fbrm',
         'Y_process_s', 'Y_process_l', 'Y_train_l', 'Y_train_s',
         'wavenumber_ram', 'wavenumber_ir', 'wavenumber_fbrm',
         'Faults', 'X_train_l_ir', 'X_train_l_ram', 'X_train_l_ram_backsub', 'X_train_s_fbrm', 'X_train_s_ram', 'Y_train_total_s', 'Y_process_total_s']
myVars = vars()
for i in range(len(file_npz)):
    myVars[variable_order[i]] = file_npz[variable_order[i]]

## Use background-subtracted Raman for solution phase
X_train_l_ram_raw = X_train_l_ram.copy()
X_train_l_ram = X_train_l_ram_backsub.copy()

n_l_train = 15
n_s_train = 16

## Original f_train and f_test split
f_normal = [0,1,2,3,4,5,6,7,13,15,18,21,22,23,24,25,26]

f_normal_select = [0,1,2,3,4,5,6,7,13,15,18,22,23,26]
f_train, f_test = TTS(f_normal_select, test_size = 0.3, random_state=19)
f_test += [21, 24, 25]
print('Validation Experiments: ' + str(len(f_train)))
print('Testing Experiments: ' + str(len(f_test)))

f_sensor = [10,11,12,14]
f_heel = [16,17,19,20]
f_boricfeed = [27]
f_gfc = [28,29]
f_carbonate = [30,31,32]
f_zircon = [33,34,35]
f_mix = [9]
f_pH = [8]

## Fouling lists. These are not exclusive from other lists.
f_foul_slight = [0,3,6,9,11,12,15,18,21,29,30]  
f_foul = [23, 24, 25, 26, 27, 28, 31, 32, 33, 34, 35] ## Very clear examples of fouling
f_clean = [1,2,4,5,7,8,10,13,14,16,17,19,20,22]
f_foul_normal = [x for x in f_normal if x in f_foul]
f_clean_normal = [x for x in f_normal if x in f_clean]

l_sensor = ['FBRM','Shroud','Raman','ATR-FTIR']
l_pH = ['pH']
l_heel = ['0.73','0.61','0.69','0.92','0.59','0.76']
l_carbonate = ['5','4','3.2']
l_zircon = ['5','4','3.2']

fault_array_true_all =  np.array([0,0,0,0,0,0,0,0,1,1,1,1,1,0,1,1,1,1,1,1,1,0,0,0,0,0,0,1,1,1,1,1,1,1,1,1])
fault_array_true_proc = np.array([0,0,0,0,0,0,0,0,1,1,1,1,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1])
fault_array_true_conc = np.array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0])
f_test_not_conc = np.array([8,9,10,11,12,13,14,21,22,23,24,25,26,30,31,32,33,34,35])

"""
Alternative Liquid Representation (Current)
"""
## Uses wt% of whole slurry (not just solution phase) for quantification
excel_train_solution_wt= pd.read_excel(directory / 'Training Concentrations.xlsx', header = None, sheet_name = 0)
excel_slurry_wt = pd.read_excel(directory_process / 'Process Concentrations.xlsx', header = None, sheet_name = 0)

## Whole slurry wt%
# Y_train_l = excel_train_solution_wt.iloc[42:57,0:4].values.astype(float)
# Y_process_l = excel_slurry_wt.iloc[85:121,5:9].values.astype(float)

## Calculate total mass of solids
Y_process_s_totalmass = excel_slurry_wt.iloc[85:121,9:13].values.astype(float).sum(axis=1)

"""
Plot of Gibbsite Fouling
"""
X_ref_ir_gibb, wavenumber_ir_gibb = spc_read([path / 'Raw Data/Other/Experiment 2024-03-19 LOD Gibbsite IR.spc'])
t_gibb_b = [30]
t_gibb = [40, 100, 135, 180, 230, 275, 310]
t_blank = np.arange(5,45,1)
X_blank = X_ref_ir_gibb[t_blank,:]
X_blank_std = np.std(X_blank - X_ref_ir_gibb[t_gibb_b,:], axis=0)
X_final = X_ref_ir_gibb[t_gibb[-1],:] - X_ref_ir_gibb[t_gibb_b,:]
Z_score_gibb = X_final/X_blank_std

t_addition1 = np.arange(51,110)
plt.figure(figsize=(8,6))
plt.xlabel('Wavenumber (cm$^{-1}$)')
plt.ylabel('Absorbance (A.U.)')
plt.xlim((1450,850))
plt.ylim(-0.01, 0.25)
color_gradient = plt.cm.winter((t_addition1-np.min(t_addition1))/(np.max(t_addition1)-np.min(t_addition1)))
for i in range(len(t_addition1)):
    plt.plot(wavenumber_ir_gibb, (X_ref_ir_gibb[t_addition1[i],:] - X_ref_ir_gibb[t_gibb_b,:]).T, color=color_gradient[i])
plt.plot(wavenumber_ir_gibb, (X_blank_std)*6, color='k', linestyle = '--')
plt.text(1042, 0.235, '1022')
plt.text(984, 0.065, '970')
plt.text(930, 0.030, '917')
plt.annotate('6-sigma of blank', 
             xy=(1300, 0.008),         # Point being annotated
             xytext=(1400, 0.05),      # Location of the annotation text
             arrowprops=dict(arrowstyle='->', color='k', lw=1),
             fontsize=20, color='k')
sm = plt.cm.ScalarMappable(cmap=plt.cm.winter, norm=plt.Normalize(vmin=0, vmax=len(t_addition1)))
ax = plt.gca()
cbar = plt.colorbar(sm, ax=ax)
cbar.ax.set_ylabel('Time (min)', rotation=90)
cbar.ax.get_yaxis().labelpad=20
if save == True:
    plt.savefig(save_folder_pdf / ('Fouling Reference' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Fouling Reference' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Fouling Reference' + '.eps'), bbox_inches='tight')


t_addition1 = np.arange(51,110)
plt.figure(figsize=(8,6))
plt.xlabel('Wavenumber (cm$^{-1}$)')
plt.ylabel('Absorbance (A.U.)')
plt.xlim((1150,800))
plt.ylim(-0.01, 0.25)
color_gradient = plt.cm.winter((t_addition1-np.min(t_addition1))/(np.max(t_addition1)-np.min(t_addition1)))
for i in range(len(t_addition1)):
    plt.plot(wavenumber_ir_gibb, (X_ref_ir_gibb[t_addition1[i],:] - X_ref_ir_gibb[t_gibb_b,:]).T, color=color_gradient[i])
plt.text(1042, 0.235, '1022')
plt.text(984, 0.065, '970')
plt.text(930, 0.030, '917')
sm = plt.cm.ScalarMappable(cmap=plt.cm.winter, norm=plt.Normalize(vmin=0, vmax=len(t_addition1)))
ax = plt.gca()
cbar = plt.colorbar(sm, ax=ax)
cbar.ax.set_ylabel('Time (min)', rotation=90)
cbar.ax.get_yaxis().labelpad=20


"""
Plot of Raw Instrument Data
"""
instrument_orig_list = ['a) Raman','b) ATR-FTIR','c) FBRM']
x_axis_orig_list = [r'Raman Shift (cm$^{-1}$)', r'Wavenumber (cm$^{-1}$)',r'Chord-Length (μm)']
y_axis_orig_list = ['Counts','Absorbance (A.U.)','Counts']
wavenumber_orig_list = [wavenumber_ram, wavenumber_ir, wavenumber_fbrm]
X_test_orig_list = [X_process_ram, X_process_ir, X_process_fbrm]

## Plot of scaled (true) training data
plt.figure(figsize=(12,8))
for i in range(4):
    if i<3:
        plt.subplot(2,2,i+1)
        plt.plot(wavenumber_orig_list[i], X_test_orig_list[i][f_train, :].T, color=color[i], zorder=1)
        plt.title(instrument_orig_list[i], loc='left', fontsize=20, fontweight='bold')
        plt.xlabel(x_axis_orig_list[i])
        plt.ylabel(y_axis_orig_list[i])
    if i==3:
        plt.subplot(2,2,i+1)
        legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, label='Raman'),
                            Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, label='ATR-FTIR'),
                            Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1,  lw=3, label='FBRM')]
        plt.legend(handles=legend_elements1, frameon=False,loc='upper left')
        plt.axis('off')
plt.subplots_adjust(wspace=.50,hspace=.50)



"""
Solution Phase Feature Selection
"""
## Feature Selection
IRmin=850        #Min is 648.8736 
IRmax=1450        #Max is 2998.2
indexmaxir=np.round(632-((IRmin-648.8736)/3.7232)).astype(int)
indexminir=np.round(632-((IRmax-648.8736)/3.7232)).astype(int)-1

wavenumber_ir = wavenumber_ir[indexminir:indexmaxir]
X_train_l_ir = X_train_l_ir[:,indexminir:indexmaxir]
X_process_ir = X_process_ir[:,indexminir:indexmaxir]

## Non-target feature removal
X_ref_ir = np.linalg.inv(Y_train_l.T@Y_train_l)@Y_train_l.T@X_train_l_ir
X_ref_ir_resid = X_process_ir[f_train,:] - X_process_ir[f_train,:]@X_ref_ir.T@np.linalg.inv(X_ref_ir@X_ref_ir.T)@X_ref_ir
X_ref_ir_NCCLS = X_ref_ir.copy()

## Standard preprocessing
X_process_ir_NCCLS = NCCLS(X_train_l_ir, Y_train_l, X_process_ir, X_ref_ir_NCCLS)  
X_process_ir_BSSICA = BSS_ICA(X_train_l_ir, X_process_ir, X_ref_ir, n_sources=5)
X_process_ir_BSSPCA = BSS_PCA(X_train_l_ir, X_process_ir, X_ref_ir, n_sources=5)
X_process_ir_nontargetremoval_full = [X_process_ir_NCCLS, X_process_ir_BSSICA, X_process_ir_BSSPCA]
nontargetremoval_names = ['NCCLS','BSS ICA','BSS PCA']

## Non-target Removal (All normal experiments)
plt.figure(figsize=(12,8))
# plt.suptitle('Non-Target Removal Methods')
for i in range(4):
    if i<3:
        plt.subplot(2,2,i+1)
        plt.xlim((IRmax, IRmin))
        plt.plot(wavenumber_ir, X_process_ir_nontargetremoval_full[i][(f_train+f_test),:].T, color=color[i], label=nontargetremoval_names[i], zorder=2)
        plt.plot(wavenumber_ir, X_process_ir[(f_train+f_test),:].T, color='k', alpha=0.7, linestyle='--', label='Unprocessed Data', zorder=1)
        plt.title(title_list[i], loc = 'left')
        plt.xlabel('Wavenumber (cm$^{-1}$)')
        plt.ylabel('Absorbance (A.U.)')
    if i==3:
        plt.subplot(2,2,i+1)
        legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, label='NCCLS'),
                            Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, label='BSS ICA'),
                            Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1,  lw=3, label='BSS PCA'),
                            Line2D([0], [0], color='k', markeredgecolor='k', linestyle = '--', alpha=0.7, lw=3, label='Original Spectra')]
        plt.legend(handles=legend_elements1, frameon=False,loc='upper left')
        plt.axis('off')
plt.subplots_adjust(wspace=.50,hspace=.50)
if save == True:
    plt.savefig(save_folder_pdf / ('Non-Target Removal' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Non-Target Removal' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Non-Target Removal' + '.eps'), bbox_inches='tight')


# ## Preprocessing of only fouling region based on manual region selection (105-123)
# index_remove = np.arange(95,138)
## Preprocessing of fouling region based on standard deviation of blank
index_remove = np.arange(len(wavenumber_ir))[X_blank_std[indexminir:indexmaxir]<(X_ref_ir_gibb[t_addition1[-1],indexminir:indexmaxir] - X_ref_ir_gibb[t_gibb_b[0],indexminir:indexmaxir])]

## Replacement of fouling region for both methods
index_replace = np.arange(len(wavenumber_ir))
index_replace = np.delete(index_replace, index_remove, axis=0)
X_process_ir_NCCLS[:,index_replace] = X_process_ir[:,index_replace]  
X_process_ir_BSSICA[:,index_replace] = X_process_ir[:,index_replace]
X_process_ir_BSSPCA[:,index_replace] = X_process_ir[:,index_replace]

X_process_ir_nontargetremoval = [X_process_ir_NCCLS, X_process_ir_BSSICA, X_process_ir_BSSPCA]
X_process_ir_unfiltered = X_process_ir.copy()

## Non-target Removal (All Experiments)
plt.figure(figsize=(12,8))
plt.suptitle('Non-Target Removal Methods')
for i in range(4):
    if i<3:
        plt.subplot(2,2,i+1)
        plt.xlim((IRmax, IRmin))
        plt.plot(wavenumber_ir, X_process_ir_nontargetremoval[i].T, color=color[i], label=nontargetremoval_names[i], zorder=2)
        plt.plot(wavenumber_ir, X_process_ir.T, color='k', alpha=0.7, linestyle='--', label='Unprocessed Data', zorder=1)
        # plt.plot(wavenumber_ir, X_process_ir_nontargetremoval[i][[23,24,25,26],:].T, color='k', alpha=1, linestyle='-', label='Unprocessed Data', zorder=3)
        plt.title(title_list[i], loc = 'left')
        plt.xlabel('Wavenumber (cm$^{-1}$)')
        plt.ylabel('Absorbance (A.U.)')
    if i==3:
        plt.subplot(2,2,i+1)
        legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, label='NCCLS'),
                            Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, label='BSS ICA'),
                            Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1,  lw=3, label='BSS PCA'),
                            Line2D([0], [0], color='k', markeredgecolor='k', linestyle = '--', alpha=0.7, lw=3, label='Original Spectra')]
        plt.legend(handles=legend_elements1, frameon=False,loc='upper left')
        plt.axis('off')
plt.subplots_adjust(wspace=.50,hspace=.50)

## Savitzky-Golay Filter
X_train_l_ir_original = X_train_l_ir.copy()
X_process_ir_original = X_process_ir.copy()
X_train_l_ir = savgol_filter(X_train_l_ir.copy(), 7, 2, 1)
X_process_ir = savgol_filter(X_process_ir.copy(), 7, 2, 1)

X_process_ir_NCCLS = savgol_filter(X_process_ir_NCCLS.copy(), 7, 2, 1)
X_process_ir_BSSICA = savgol_filter(X_process_ir_BSSICA.copy(), 7, 2, 1)
X_process_ir_BSSPCA = savgol_filter(X_process_ir_BSSPCA.copy(), 7, 2, 1)

"""
Slurry Phase Feature Selection ( + Solution-Phase Raman)
"""

RamanMin=200        #Min is 100
# RamanMax=800       #Max is 3200
RamanMax=1600       #Max is 3200
# RamanMax=500       #Max is 3200
indexmaxram=3201-RamanMin
indexminram=3200-RamanMax

## Savitzky-Golay Filter
X_train_s_ram_savgol = savgol_filter(X_train_s_ram.copy(), 19, 2, 1)
X_process_ram_savgol = savgol_filter(X_process_ram.copy(), 19, 2, 1)
X_train_l_ram_savgol = savgol_filter(X_train_l_ram.copy(), 19, 2, 1)

wavenumber_ram = wavenumber_ram[indexminram:indexmaxram]
X_train_s_ram = X_train_s_ram[:,indexminram:indexmaxram]
X_process_ram = X_process_ram[:,indexminram:indexmaxram]
X_train_l_ram = X_train_l_ram[:,indexminram:indexmaxram]
X_train_s_ram_savgol = X_train_s_ram_savgol[:,indexminram:indexmaxram]
X_process_ram_savgol = X_process_ram_savgol[:,indexminram:indexmaxram]
X_train_l_ram_savgol = X_train_l_ram_savgol[:,indexminram:indexmaxram]


indexminfbrm = 0
# indexmaxfbrm = 90 ## Puts two normal points as outliers
indexmaxfbrm = 65
X_train_s_fbrm = X_train_s_fbrm[:,indexminfbrm:indexmaxfbrm]
X_process_fbrm = X_process_fbrm[:,indexminfbrm:indexmaxfbrm]
wavenumber_fbrm = wavenumber_fbrm[indexminfbrm:indexmaxfbrm]

plt.figure(figsize=(8,6))
plt.plot(wavenumber_fbrm, X_process_fbrm.T, color = color[0], zorder = 1, label = 'FBRM Data')
plt.plot(wavenumber_fbrm, X_process_fbrm[21,:].T, color = 'k', zorder = 2, label = 'Outlier')
plt.xlabel(r'Chord Length (μm)')
plt.ylabel(r'Counts')
plt.title('FBRM Data')
legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Process Data'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Outlier'),]
plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')

## Raman data outliers
plt.figure(figsize=(8,6))
plt.plot(wavenumber_ram, X_process_ram[f_train,:].T, color = color[0], zorder = 1, label = 'Raman Data')
plt.plot(wavenumber_ram, X_process_ram[[24],:].T, color = 'k', linestyle = linestyle[0], zorder = 2, label = 'Outlier')
plt.plot(wavenumber_ram, X_process_ram[[25],:].T, color = 'k', linestyle = linestyle[1], zorder = 2, label = 'Outlier')
plt.xlabel(r'Raman Shift (cm$^{-1}$)')
plt.ylabel(r'Counts')
# plt.title('Raman Data')
plt.xlim((350,450))
legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Raman Val. Data'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Outlier 1'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[1], label='Outlier 2'),]
plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')
if save == True:
    plt.savefig(save_folder_pdf / ('Raman Outlier Raw' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Raman Outlier Raw' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Raman Outlier Raw' + '.eps'), bbox_inches='tight')

## Raman data and FBRM data in single plot
plt.figure(figsize=(8,8))
plt.subplot(2,1,1)
plt.plot(wavenumber_ram, X_process_ram_savgol[f_train,:].T, color = color[0], zorder = 1, label = 'Raman Data')
plt.plot(wavenumber_ram, X_process_ram_savgol[[24,25],:].T, color = 'k', zorder = 2, label = 'Outlier')
plt.xlabel(r'Raman Shift (cm$^{-1}$)')
plt.ylabel(r'Counts (1$^{st}$ Derivative)')
plt.title('a)', loc='left', fontsize=20, fontweight='bold')
plt.xlim((200,500))
legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Raman Val. Data'),
                    Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='FBRM Val. Data'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Outlier Val. Data'),]
plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')
plt.subplot(2,1,2)
plt.plot(wavenumber_fbrm, X_process_fbrm[f_train,:].T, color = color[2], zorder = 1, label = 'FBRM Data')
plt.plot(wavenumber_fbrm, X_process_fbrm[21,:].T, color = 'k', zorder = 2, label = 'Outlier')
## Carbonate Outlier Hotelling
# plt.plot(wavenumber_fbrm, X_process_fbrm[[30],:].T, color = 'k', zorder = 2, label = 'Outlier')
plt.xlim((0, 60))
plt.ylim((0, 1.1 * X_process_fbrm.max()))
plt.xlabel(r'Chord Length (μm)')
plt.ylabel(r'Counts')
plt.title('b)', loc='left', fontsize=20, fontweight='bold')
plt.subplots_adjust(wspace=.50,hspace=.50)
if save == True:
    plt.savefig(save_folder_pdf / ('Raman Outlier' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Raman Outlier' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Raman Outlier' + '.eps'), bbox_inches='tight')


plt.figure(figsize=(8,6))
plt.plot(wavenumber_fbrm, X_process_fbrm[f_train,:].T, color = color[2], zorder = 1, label = 'FBRM Data')
plt.plot(wavenumber_fbrm, X_process_fbrm[30,:].T, color = 'k', zorder = 2, label = 'Outlier')
## Carbonate Outlier Hotelling
# plt.plot(wavenumber_fbrm, X_process_fbrm[[30],:].T, color = 'k', zorder = 2, label = 'Outlier')
plt.xlim((0, 60))
plt.ylim((0, 1.1 * X_process_fbrm.max()))
plt.xlabel(r'Chord Length (μm)')
plt.ylabel(r'Counts')
# plt.title('b)', loc='left', fontsize=20, fontweight='bold')
legend_elements1= [Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='FBRM Val. Data'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Outlier'),]
plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')
# plt.subplots_adjust(wspace=.50,hspace=.50)
if save == True:
    plt.savefig(save_folder_pdf / ('Carbonate Outlier' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Carbonate Outlier' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Carbonate Outlier' + '.eps'), bbox_inches='tight')

"""
Q-Factor and Hotelling T2 Functions
"""
def Qfactor(X_test, model):
    X_temp = model.transform(X_test)
    X_predicted = model.inverse_transform(X_temp)
    Q = np.sum(np.square(X_test - X_predicted), axis=1)
    return Q

def Hotelling(X_test, model, n_factors):
    X_reduced = model.transform(X_test)
    T = np.zeros((np.size(X_test, axis=0), n_factors))
    eigenvalues = model.explained_variance_
    
    ## Matrix method with vectors
    T_sum = np.zeros((np.size(X_test, axis=0)))
    for i in range(np.size(X_test, axis=0)):
        T_sum[i] = X_reduced[i:(i+1),:] @ np.linalg.inv(np.diag(eigenvalues[:n_factors])) @ X_reduced[i:(i+1),:].T
    
    return T, T_sum

"""
Fault Detection Data Preparation
"""

## Using solid + solution phase Raman data
X_train_l_ir_FD = np.vstack((X_train_l_ir, np.mean(X_train_l_ir, axis=0).reshape(1,-1), X_train_l_ir, np.mean(X_train_l_ir, axis=0).reshape(1,-1)))
X_train_s_ram_FD = np.vstack((X_train_s_ram_savgol, X_train_l_ram_savgol, np.mean(X_train_l_ram_savgol, axis=0).reshape(1,-1)))
X_train_s_fbrm_FD = np.vstack((X_train_s_fbrm, X_train_s_fbrm))

X_process_ir_FD = X_process_ir.copy()
X_process_ir_NCCLS_FD = X_process_ir_NCCLS.copy()
X_process_ir_BSSICA_FD = X_process_ir_BSSICA.copy()
X_process_ir_BSSPCA_FD = X_process_ir_BSSPCA.copy()
X_process_ram_FD = X_process_ram_savgol.copy()
X_process_fbrm_FD = X_process_fbrm.copy()

X_train_FD = np.hstack((X_train_s_ram_FD, X_train_l_ir_FD, X_train_s_fbrm_FD))
X_test_FD = np.hstack((X_process_ram_FD, X_process_ir_FD, X_process_fbrm_FD)) 
X_test_FD_NCCLS = np.hstack((X_process_ram_FD, X_process_ir_NCCLS_FD, X_process_fbrm_FD)) 
X_test_FD_BSSICA = np.hstack((X_process_ram_FD, X_process_ir_BSSICA_FD, X_process_fbrm_FD)) 
X_test_FD_BSSPCA = np.hstack((X_process_ram_FD, X_process_ir_BSSPCA_FD, X_process_fbrm_FD)) 

wavenumber_FD = np.arange(np.size(X_test_FD, axis=1))
wavenumber_FD_list = [wavenumber_ram, wavenumber_ir, wavenumber_fbrm]
wavenumber_lim_list = [[np.min(wavenumber_ram), np.max(wavenumber_ram)], [np.max(wavenumber_ir), np.min(wavenumber_ir)], [0, np.max(wavenumber_fbrm)]]
in_ram = np.arange(np.size(X_process_ram_FD, axis=1))
in_ir = np.arange(np.max(in_ram) + 1, np.size(X_process_ir_FD, axis=1) + np.max(in_ram) + 1)
in_fbrm = np.arange(np.max(in_ir) + 1, np.size(X_process_fbrm_FD, axis=1) + np.max(in_ir) + 1)
in_list = [in_ram, in_ir, in_fbrm]

## Scaling
scaler = StandardScaler()
scaler.fit(X_train_FD)
X_train_FD = scaler.transform(X_train_FD)
X_test_FD = scaler.transform(X_test_FD)
X_test_FD_NCCLS = scaler.transform(X_test_FD_NCCLS)
X_test_FD_BSSICA = scaler.transform(X_test_FD_BSSICA)
X_test_FD_BSSPCA = scaler.transform(X_test_FD_BSSPCA)

"""
Fault Detection
"""
n_components = 4
model_pca = PCA(n_components = n_components); model_pca.fit(X_train_FD)
Q = Qfactor(X_test_FD_NCCLS, model_pca).reshape(-1,1)
Q_orig = Qfactor(X_test_FD, model_pca).reshape(-1,1)

T, T_sum = Hotelling(X_test_FD_NCCLS, model_pca, n_components)
T_orig, T_sum_orig = Hotelling(X_test_FD, model_pca, n_components)
## Actual training data
Q_acttrain = Qfactor(X_train_FD, model_pca).reshape(-1,1)
T, T_sum_acttrain = Hotelling(X_train_FD, model_pca, n_components)

T_sum_train = T_sum[f_train]
T_sum_normal = T_sum[f_test]
T_sum_sensorfault = T_sum[f_sensor]
T_sum_processfault = T_sum[f_heel]
T_sum_list = [T_sum_train, T_sum_normal, T_sum_sensorfault, T_sum_processfault]

Q_train = Q[f_train]
Q_normal = Q[f_test]
Q_sensorfault = Q[f_sensor]
Q_processfault = Q[f_heel]
Q_list = [Q_train, Q_normal, Q_sensorfault, Q_processfault]

T_sum_train_orig = T_sum_orig[f_train]
T_sum_normal_orig = T_sum_orig[f_test]
T_sum_sensorfault_orig = T_sum_orig[f_sensor]
T_sum_processfault_orig = T_sum_orig[f_heel]
T_sum_list_orig = [T_sum_train_orig, T_sum_normal_orig, T_sum_sensorfault_orig, T_sum_processfault_orig]

Q_train_orig = Q_orig[f_train]
Q_normal_orig = Q_orig[f_test]
Q_sensorfault_orig = Q_orig[f_sensor]
Q_processfault_orig = Q_orig[f_heel]
Q_list_orig = [Q_train_orig, Q_normal_orig, Q_sensorfault_orig, Q_processfault_orig]

"""
Fault Detection with Single Instruments
"""

X_train_FD_ram = X_train_FD[:, in_list[0]]
X_train_FD_ir = X_train_FD[:, in_list[1]]
X_train_FD_fbrm = X_train_FD[:, in_list[2]]

X_test_FD_NCCLS_ram = X_test_FD_NCCLS[:, in_list[0]]
X_test_FD_NCCLS_ir = X_test_FD_NCCLS[:, in_list[1]]
X_test_FD_NCCLS_fbrm = X_test_FD_NCCLS[:, in_list[2]]

n_components = 4
model_pca_ram = PCA(n_components = n_components); model_pca_ram.fit(X_train_FD_ram)
model_pca_ir = PCA(n_components = n_components); model_pca_ir.fit(X_train_FD_ir)
model_pca_fbrm = PCA(n_components = n_components); model_pca_fbrm.fit(X_train_FD_fbrm)

Q_ram = Qfactor(X_test_FD_NCCLS_ram, model_pca_ram).reshape(-1,1)
Q_ir = Qfactor(X_test_FD_NCCLS_ir, model_pca_ir).reshape(-1,1)
Q_fbrm = Qfactor(X_test_FD_NCCLS_fbrm, model_pca_fbrm).reshape(-1,1)

T, T_sum_ram = Hotelling(X_test_FD_NCCLS_ram, model_pca_ram, n_components)
T, T_sum_ir = Hotelling(X_test_FD_NCCLS_ir, model_pca_ir, n_components)
T, T_sum_fbrm = Hotelling(X_test_FD_NCCLS_fbrm, model_pca_fbrm, n_components)

"""
Scree Plot
"""

variance_ratio = model_pca.explained_variance_ratio_

plt.figure(figsize=(8,6))
plt.plot(np.arange(n_components)+1, variance_ratio, linewidth = 0, color=color[1], marker=marker[2])
for i in range(n_components):
    if i == 0:
        plt.text(1.3, 0.83, str(round(variance_ratio[i],3)), fontsize=16)
    elif i == n_components - 1:
        plt.text(i+0.4, variance_ratio[i] + 0.1, str(round(variance_ratio[i],3)), fontsize=16)
    else:
        plt.text(i+0.5, variance_ratio[i] + 0.1, str(round(variance_ratio[i],3)), fontsize=16)
plt.plot(np.arange(n_components)+1, 0.01*np.ones(n_components), linestyle = '--',color='k', label='1% Variance')
plt.xlabel('Principal Component')
plt.ylabel('Fractional Variance')
plt.ylim((0, 1))
plt.xlim((1, n_components))
plt.legend(loc='upper right')

"""
Plots
"""
## Plot of original ATR-FTIR spectra showing spectra with and without fouling
plt.figure(figsize=(8,6))
plt.plot(wavenumber_ir, X_train_l_ir_original.T, color='k', linestyle = linestyle[0])
plt.plot(wavenumber_ir, X_process_ir_original[f_clean_normal,:].T, color=color[2], alpha=0.7, linestyle = linestyle[0])
# plt.plot(wavenumber_ir, X_process_ir_original[f_foul_slight,:].T, color=color[1], linestyle = linestyle[4])
plt.plot(wavenumber_ir, X_process_ir_original[f_foul_normal,:].T, color=color[1], linestyle = linestyle[0])
plt.xlabel('Wavenumber (cm$^{-1}$)')
plt.ylabel('Absorbance (A.U.)')
legend_elements1= [Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Training Data'),
                    Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=0.7, lw=3, linestyle = linestyle[0], label='Clean'),
                    # Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1,  lw=3, linestyle = linestyle[4], label='Slightly Fouled'),
                    Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Signficantly Fouled')]
plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')
plt.xlim((IRmax, IRmin))
# plt.xlim((1070,970))
if save == True:
    plt.savefig(save_folder_pdf / ('IR Fouling' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('IR Fouling' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('IR Fouling' + '.eps'), bbox_inches='tight')

instrument_list = ['a) Raman','b) ATR-FTIR','c) FBRM']
x_axis_list = [r'Wavenumber (cm$^{-1}$)', r'Wavenumber (cm$^{-1}$)',r'Chord-Length (μm)']
y_axis_list = ['Scaled Counts','Scaled Absorbance','Scaled Counts']

## Combined Plot of scaled training and validation data
instrument_list_combined = ['a)','b)','c)', 'd)','e)','f)']
plt.figure(figsize=(12,6))
for i in range(6):
    if i<3:
        plt.subplot(2,3,i+1)
        plt.xlim(wavenumber_lim_list[i])
        plt.plot(wavenumber_FD_list[i], X_train_FD[:, in_list[i]].T, color=color[i], zorder=1)
        plt.title(instrument_list_combined[i], loc='left', fontsize=20, fontweight='bold')
        plt.xlabel(x_axis_list[i])
        plt.ylabel(y_axis_list[i])
    elif 2<i<6:
        plt.subplot(2,3,i+1)
        j=i-3
        plt.xlim(wavenumber_lim_list[j])
        plt.plot(wavenumber_FD_list[j], X_test_FD[np.ix_(f_train, in_list[j])].T, color=color[j], zorder=1)
        plt.title(instrument_list_combined[i], loc='left', fontsize=20, fontweight='bold')
        plt.xlabel(x_axis_list[j])
        plt.ylabel(y_axis_list[j])
    if i==2:
        plt.subplot(2,3,i+1)
        legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, label='Raman'),
                            Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, label='ATR-FTIR'),
                            Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1,  lw=3, label='FBRM')]
        plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1.1,1.05), loc='upper left')
plt.subplots_adjust(wspace=.50,hspace=1)
if save == True:
    plt.savefig(save_folder_pdf / ('SNV Comparing Data' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('SNV Comparing Data' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('SNV Comparing Data' + '.eps'), bbox_inches='tight')

## Combined plot of scaled training and validation data with NCCLS
instrument_list_combined = ['a)','b)','c)', 'd)','e)','f)']
plt.figure(figsize=(12,6))
for i in range(6):
    if i<3:
        plt.subplot(2,3,i+1)
        plt.xlim(wavenumber_lim_list[i])
        plt.plot(wavenumber_FD_list[i], X_train_FD[:, in_list[i]].T, color=color[i], zorder=1)
        plt.title(instrument_list_combined[i], loc='left', fontsize=20, fontweight='bold')
        plt.xlabel(x_axis_list[i])
        plt.ylabel(y_axis_list[i])
    elif 2<i<6:
        plt.subplot(2,3,i+1)
        j=i-3
        plt.xlim(wavenumber_lim_list[j])
        plt.plot(wavenumber_FD_list[j], X_test_FD_NCCLS[np.ix_(f_train, in_list[j])].T, color=color[j], zorder=1)
        plt.title(instrument_list_combined[i], loc='left', fontsize=20, fontweight='bold')
        plt.xlabel(x_axis_list[j])
        plt.ylabel(y_axis_list[j])
    if i==2:
        plt.subplot(2,3,i+1)
        legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, label='Raman'),
                            Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, label='ATR-FTIR'),
                            Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1,  lw=3, label='FBRM')]
        plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1.1,1.05), loc='upper left')
    plt.ylim((-5,5))
plt.subplots_adjust(wspace=.50,hspace=1)
if save == True:
    plt.savefig(save_folder_pdf / ('SNV Comparing Data NCCLS' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('SNV Comparing Data NCCLS' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('SNV Comparing Data NCCLS' + '.eps'), bbox_inches='tight')

## Plot of Spectra highlighting outliers
## NEED to show 24, 25 (Raman) and 21 (FBRM)
plt.figure(figsize=(12,8))
for i in range(4):
    if i<3:
        plt.subplot(2,2,i+1)
        plt.xlim(wavenumber_lim_list[i])
        for j in range(36):
            if j in [24,25]: ##Outliers in Raman spectrum after Savitzky-Golay Filtering 
                plt.plot(wavenumber_FD_list[i], X_test_FD_NCCLS[j, in_list[i]].T, color='k', zorder=2)
            elif j in [21]: ## Outlier in FBRM, relatively low total solids
                plt.plot(wavenumber_FD_list[i], X_test_FD_NCCLS[j, in_list[i]].T, color='k', linestyle = '--', zorder=3)
            elif j in f_train: 
                plt.plot(wavenumber_FD_list[i], X_test_FD_NCCLS[j, in_list[i]].T, color=color[i], zorder=1)
        plt.title(instrument_list[i], loc = 'left')
        plt.xlabel(x_axis_list[i])
        plt.ylabel(y_axis_list[i])
    if i==0:
        plt.ylim((-8,8))
        plt.xlim((200,500))
    if i==3:
        plt.subplot(2,2,i+1)
        legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, label='Validation Raman'),
                            Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, label='Validation ATR-FTIR'),
                            Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1,  lw=3, label='Validation FBRM'),
                            Line2D([0], [0], color='k', markeredgecolor='k', alpha=0.9, lw=3, label='Raman Outliers'),
                            Line2D([0], [0], color='k', markeredgecolor='k', linestyle = '--', alpha=0.9, lw=3, label='FBRM Outlier')]
        plt.legend(handles=legend_elements1, frameon=False,loc='upper left')
        plt.axis('off')
    if i==2:
        plt.ylim((-5,5))
plt.subplots_adjust(wspace=.50,hspace=.50)
if save == True:
    plt.savefig(save_folder_pdf / ('SNV Outliers' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('SNV Outliers' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('SNV Outliers' + '.eps'), bbox_inches='tight')

## Plot highlighting outliers in scaled and unscaled spectra
plt.figure(figsize=(12,8))
plt.subplot(2,2,1)
plt.xlim(wavenumber_lim_list[0])
for j in range(36):
    if j in [24]: ##Outliers in Raman spectrum after Savitzky-Golay Filtering 
        plt.plot(wavenumber_FD_list[0], X_test_FD_NCCLS[j, in_list[0]].T, color='k', linestyle = linestyle[0], zorder=2)
    elif j in [25]: ##Outliers in Raman spectrum after Savitzky-Golay Filtering 
        plt.plot(wavenumber_FD_list[0], X_test_FD_NCCLS[j, in_list[0]].T, color='k', linestyle = linestyle[1], zorder=2)
    elif j in [21]: ## Outlier in FBRM, relatively low total solids
        plt.plot(wavenumber_FD_list[0], X_test_FD_NCCLS[j, in_list[0]].T, color='k', linestyle = linestyle[2], zorder=3)
    elif j in f_train: 
        plt.plot(wavenumber_FD_list[0], X_test_FD_NCCLS[j, in_list[0]].T, color=color[0], zorder=1)
# plt.title(instrument_list[0], loc = 'left')
plt.xlabel(x_axis_list[0])
plt.ylabel(y_axis_list[0])
plt.ylim((-8,8))
plt.xlim((370,420))
plt.title('a) Raman Scaled', loc='left', fontsize=20, fontweight='bold')

plt.subplot(2,2,3)
plt.xlim(wavenumber_lim_list[2])
for j in range(36):
    if j in [24]: ##Outliers in Raman spectrum after Savitzky-Golay Filtering 
        plt.plot(wavenumber_FD_list[2], X_test_FD_NCCLS[j, in_list[2]].T, color='k', linestyle = linestyle[0], zorder=2)
    elif j in [25]: ##Outliers in Raman spectrum after Savitzky-Golay Filtering 
        plt.plot(wavenumber_FD_list[2], X_test_FD_NCCLS[j, in_list[2]].T, color='k', linestyle = linestyle[1], zorder=2)
    elif j in [21]: ## Outlier in FBRM, relatively low total solids
        plt.plot(wavenumber_FD_list[2], X_test_FD_NCCLS[j, in_list[2]].T, color='k', linestyle = linestyle[2], zorder=3)
    elif j in f_train: 
        plt.plot(wavenumber_FD_list[2], X_test_FD_NCCLS[j, in_list[2]].T, color=color[2], zorder=1)
plt.xlabel(x_axis_list[2])
plt.ylabel(y_axis_list[2])
plt.title('c) FBRM Scaled', loc='left', fontsize=20, fontweight='bold')
plt.ylim((-4,4))

plt.subplot(2,2,2)
plt.plot(wavenumber_ram, X_process_ram_savgol[f_train,:].T, color = color[0], zorder = 1, label = 'Raman Data')
plt.plot(wavenumber_ram, X_process_ram_savgol[[24],:].T, color = 'k', linestyle = linestyle[0], zorder = 2, label = 'Outlier')
plt.plot(wavenumber_ram, X_process_ram_savgol[[25],:].T, color = 'k', linestyle = linestyle[1], zorder = 2, label = 'Outlier')
plt.plot(wavenumber_ram, X_process_ram_savgol[[21],:].T, color = 'k', linestyle = linestyle[2], zorder = 2, label = 'Outlier')
plt.xlabel(r'Raman Shift (cm$^{-1}$)')
plt.ylabel(r'Counts (1$^{st}$ Derivative)')
plt.title('b) Raman Unscaled', loc='left', fontsize=20, fontweight='bold')
plt.xlim((370,420))
plt.ylim((-200,200))
legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Raman Val. Data'),
                    Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='FBRM Val. Data'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Outlier 1'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[1], label='Outlier 2'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[2], label='Near Outlier')]
plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')
plt.subplot(2,2,4)
plt.plot(wavenumber_fbrm, X_process_fbrm[f_train,:].T, color = color[2], zorder = 1, label = 'FBRM Data')
plt.plot(wavenumber_fbrm, X_process_fbrm[21,:].T, color = 'k', linestyle = linestyle[2], zorder = 2, label = 'Outlier')
plt.plot(wavenumber_fbrm, X_process_fbrm[24,:].T, color = 'k', linestyle = linestyle[0], zorder = 2, label = 'Outlier')
plt.plot(wavenumber_fbrm, X_process_fbrm[25,:].T, color = 'k', linestyle = linestyle[1], zorder = 2, label = 'Outlier')
plt.xlim((0, 60))
plt.ylim((0, 1.1 * X_process_fbrm.max()))
plt.xlabel(r'Chord Length (μm)')
plt.ylabel(r'Counts')
plt.title('d) FBRM Unscaled', loc='left', fontsize=20, fontweight='bold')
plt.subplots_adjust(wspace=.50,hspace=.50)
if save == True:
    plt.savefig(save_folder_pdf / ('Raman Outlier Condensed' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Raman Outlier Condensed' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Raman Outlier Condensed' + '.eps'), bbox_inches='tight')

## Zooming in on abnormal Raman behavior ## X_train_s_ram_savgol number 4 is outlier in the training data
plt.figure(figsize=(8,6))
plt.plot(wavenumber_ram, X_process_ram_savgol[f_train,:].T, color = color[0], zorder = 1, label = 'Raman Data')
plt.plot(wavenumber_ram, X_process_ram_savgol[[24],:].T, color = 'k',linestyle=linestyle[0], zorder = 2, label = 'Outlier')
plt.plot(wavenumber_ram, X_process_ram_savgol[[25],:].T, color = 'k', linestyle=linestyle[1], zorder = 2, label = 'Outlier')
plt.plot(wavenumber_ram, X_train_l_ram_savgol.T, color = color[1], zorder=3)
plt.plot(wavenumber_ram, X_train_s_ram_savgol[:,:].T, color = color[2], zorder=3)
# plt.plot(wavenumber_ram, X_train_s_ram_savgol[4:5,:].T, color = color[2], zorder=3)
plt.xlabel(r'Raman Shift (cm$^{-1}$)')
plt.ylabel(r'Counts (1$^{st}$ Derivative)')
# plt.title('Raman Unscaled', loc='left', fontsize=20, fontweight='bold')
plt.xlim((380,390))
plt.ylim((-10,18))
legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Raman Val. Data'),
                    Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Raman Solu. Train Data'),
                    Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Raman Insolu. Train Data'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Outlier 1'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[1], label='Outlier 2')]
plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')
if save == True:
    plt.savefig(save_folder_pdf / ('Raman Outlier Zoomed' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Raman Outlier Zoomed' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Raman Outlier Zoomed' + '.eps'), bbox_inches='tight')

## Zooming in on abnormal Raman behavior without savgol filtering ## X_train_s_ram_savgol number 4 is outlier in the training data
plt.figure(figsize=(8,6))
plt.plot(wavenumber_ram, X_process_ram[f_train,:].T, color = color[0], zorder = 1, label = 'Raman Data')
plt.plot(wavenumber_ram, X_process_ram[[24],:].T, color = 'k',linestyle=linestyle[0], zorder = 2, label = 'Outlier')
plt.plot(wavenumber_ram, X_process_ram[[25],:].T, color = 'k', linestyle=linestyle[1], zorder = 2, label = 'Outlier')
plt.plot(wavenumber_ram, X_train_l_ram.T, color = color[1], zorder=3)
plt.plot(wavenumber_ram, X_train_s_ram[:,:].T, color = color[2], zorder=3)
# plt.plot(wavenumber_ram, X_train_s_ram_savgol[4:5,:].T, color = color[2], zorder=3)
plt.xlabel(r'Raman Shift (cm$^{-1}$)')
plt.ylabel(r'Counts (1$^{st}$ Derivative)')
# plt.title('Raman Unscaled', loc='left', fontsize=20, fontweight='bold')
# plt.xlim((380,390))
plt.xlim((350,420))
plt.ylim((0,20000))
legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Raman Val. Data'),
                    Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Raman Solu. Train Data'),
                    Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Raman Insolu. Train Data'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[0], label='Outlier 1'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle = linestyle[1], label='Outlier 2')]
plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')

## Plot of Showing outliers in ALL data (Updated)
## Faults to show: carbonate IR, zircon Raman, three sensor, stirrer FBRM, pH
out_inst_list = [1, 1, 0, 0, 0, 1, 2, 2]
out_title_list = ['a) Shifted pH','b) Carbonate','c) Zircon', 'd) Raman Shroud','e) Raman Failure','f) ATR-FTIR Failure','g) FBRM Failure','h) Mixing Failure']
# out_exper_list = [f_pH, f_carbonate, f_zircon, f_sensor[1:2], f_sensor[2:3], f_sensor[3:4], f_sensor[0:1], f_mix]
out_exper_list = [f_pH, f_carbonate, f_carbonate, f_sensor[1:2], f_sensor[2:3], f_sensor[3:4], f_sensor[0:1], f_mix]
plt.figure(figsize=(12,12))
for i in range(8):
    plt.subplot(3,3,i+1)
    plt.xlim(wavenumber_lim_list[out_inst_list[i]])
    plt.plot(wavenumber_FD_list[out_inst_list[i]], X_test_FD_NCCLS[np.ix_(out_exper_list[i], in_list[out_inst_list[i]])].T, color='k', linestyle='-')
    plt.plot(wavenumber_FD_list[out_inst_list[i]], X_test_FD_NCCLS[np.ix_(f_train, in_list[out_inst_list[i]])].T, color=color[out_inst_list[i]])
    plt.xlabel(x_axis_list[out_inst_list[i]])
    plt.ylabel(y_axis_list[out_inst_list[i]])
    plt.title(out_title_list[i], loc='left', fontsize=20, fontweight='bold')
plt.subplots_adjust(wspace=.50,hspace=.75)
plt.subplot(3,3,9)
legend_elements1= [Line2D([0], [0], color=color[0], markeredgecolor='k', alpha=1, lw=3, label='Validation Raman'),
                    Line2D([0], [0], color=color[1], markeredgecolor='k', alpha=1, lw=3, label='Validation ATR-FTIR'),
                    Line2D([0], [0], color=color[2], markeredgecolor='k', alpha=1,  lw=3, label='Validation FBRM'),
                    Line2D([0], [0], color='k', markeredgecolor='k', alpha=1, lw=3, linestyle='-', label='Outlier')]
plt.legend(handles=legend_elements1, frameon=False,bbox_to_anchor=(-0.3,1),loc='upper left')
plt.axis('off')
if save == True:
    plt.savefig(save_folder_pdf / ('Fault Data' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Fault Data' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Fault Data' + '.eps'), bbox_inches='tight')

"""
Solution Phase Process Quantification
"""
## All Solution Phase
plsr_ir = PLSR(n_components = 4, scale = True)
plsr_ir.fit(X_train_l_ir, Y_train_l)

y_hat_ir = plsr_ir.predict(X_process_ir); y_hat_ir[y_hat_ir<0] = 0
y_hat_ir_NCCLS = plsr_ir.predict(X_process_ir_NCCLS); y_hat_ir_NCCLS[y_hat_ir_NCCLS<0] = 0
y_hat_ir_BSSICA = plsr_ir.predict(X_process_ir_BSSICA); y_hat_ir_BSSICA[y_hat_ir_BSSICA<0] = 0
y_hat_ir_BSSPCA = plsr_ir.predict(X_process_ir_BSSPCA); y_hat_ir_BSSPCA[y_hat_ir_BSSPCA<0] = 0
y_hat_ir_list = [y_hat_ir, y_hat_ir_NCCLS, y_hat_ir_BSSICA, y_hat_ir_BSSPCA]

rmse_ir = RMSE(Y_process_l[f_train + f_test,:].reshape(-1,1), y_hat_ir[f_train + f_test,:].reshape(-1,1), multioutput = 'raw_values')
rmse_ir_NCCLS = RMSE(Y_process_l[f_train + f_test,:].reshape(-1,1), y_hat_ir_NCCLS[f_train + f_test,:].reshape(-1,1), multioutput = 'raw_values')
rmse_ir_BSSICA = RMSE(Y_process_l[f_train + f_test,:].reshape(-1,1), y_hat_ir_BSSICA[f_train + f_test,:].reshape(-1,1), multioutput = 'raw_values')
rmse_ir_BSSPCA = RMSE(Y_process_l[f_train + f_test,:].reshape(-1,1), y_hat_ir_BSSPCA[f_train + f_test,:].reshape(-1,1), multioutput = 'raw_values')
rmse_ir_list = [rmse_ir, rmse_ir_NCCLS, rmse_ir_BSSICA, rmse_ir_BSSPCA]

"""
ATR-FTIR Error (for wt% study)
"""
excel_atrftir_error = pd.read_excel(path / 'Raw Data/Other/wt% Study.xlsx', header = 2, sheet_name = 0)
atrftir_abserror_all = (excel_atrftir_error.iloc[:,0:4].values.astype(float))
atrftir_abserror_sol = (excel_atrftir_error.iloc[:,5:9].values.astype(float))

atrftir_abserror_all_fs = atrftir_abserror_all[f_train + f_test, :].reshape(-1,1)
atrftir_abserror_sol_fs = atrftir_abserror_sol[f_train + f_test, :].reshape(-1,1)
Y_process_s_totalmass_fs = np.vstack((Y_process_s_totalmass[f_train + f_test],Y_process_s_totalmass[f_train + f_test],Y_process_s_totalmass[f_train + f_test],Y_process_s_totalmass[f_train + f_test])).reshape(-1,1)

"""
ATR-FTIR Error Plot
"""
model_atrftir_error_all = LinearRegression()
model_atrftir_error_all.fit(Y_process_s_totalmass_fs, atrftir_abserror_all_fs)
y_fit_atrftir_error_all = model_atrftir_error_all.predict(Y_process_s_totalmass_fs)

model_atrftir_error_sol = LinearRegression()
model_atrftir_error_sol.fit(Y_process_s_totalmass_fs, atrftir_abserror_sol_fs)
y_fit_atrftir_error_sol = model_atrftir_error_sol.predict(Y_process_s_totalmass_fs)

## Calculating the line of best fit
m_all, b_all = np.polyfit(Y_process_s_totalmass_fs.reshape(-1), atrftir_abserror_all_fs.reshape(-1), 1)
m_sol, b_sol = np.polyfit(Y_process_s_totalmass_fs.reshape(-1), atrftir_abserror_sol_fs.reshape(-1), 1)


plt.figure(figsize = (8,6))
plt.plot(Y_process_s_totalmass_fs, atrftir_abserror_all_fs, linewidth = 0, color=color[6], marker=marker[4])
plt.plot(Y_process_s_totalmass_fs, atrftir_abserror_sol_fs, linewidth = 0, color=color[5], marker=marker[5])
plt.plot([Y_process_s_totalmass_fs.min(), Y_process_s_totalmass_fs.max()], [m_all*Y_process_s_totalmass_fs.min()+b_all, m_all*Y_process_s_totalmass_fs.max()+b_all], linewidth = 2, linestyle = '--', color=color[6])
plt.plot([Y_process_s_totalmass_fs.min(), Y_process_s_totalmass_fs.max()], [m_sol*Y_process_s_totalmass_fs.min()+b_sol, m_sol*Y_process_s_totalmass_fs.max()+b_sol], linewidth = 2, linestyle = '--', color=color[5])
plt.legend(bbox_to_anchor=(1,1.05), loc='upper left')
plt.xlabel('Mass of Solids (g)')
plt.ylabel('Prediction Error (wt%)')
legend_elements1= [Line2D([0], [0], color=color[6], marker=marker[4], markeredgecolor='k', alpha=1, markersize = 12, lw=0, label='wt%'),
                    Line2D([0], [0], color=color[5], marker=marker[5], markeredgecolor='k', alpha=1, markersize = 12, lw=0, label='wt% (Solution Only)'),
                    Line2D([0], [0], color=color[6], marker=marker[4], markeredgecolor='k', alpha=1,  markersize = 0, lw=2, linestyle='--', label='wt% Fit'),
                    Line2D([0], [0], color=color[5], marker=marker[5], markeredgecolor='k', alpha=1,  markersize = 0, lw=2, linestyle='--', label='wt% (Solution Only) Fit')]
plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')
if save == True:
    plt.savefig(save_folder_pdf / ('wt%' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('wt%' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('wt%' + '.eps'), bbox_inches='tight')

"""
ATR-FTIR Quantification Plots
"""
method_list = ['Original Spectra','NCCLS','BSS ICA','BSS PCA']
## Non-target Removal Quantification Test Data
plt.figure(figsize=(12,8))
for i in range(4):
    plt.subplot(2,2,i+1)
    plt.xlim((0, 11))
    plt.ylim((0, 11))
    for j in range(4):
        plt.plot(Y_process_l[f_test + f_train,j], y_hat_ir_list[i][f_test + f_train,j], color=color[j], marker = marker[j], markersize = 12, linewidth = 0, markeredgecolor = 'k', markeredgewidth = 1, label='Original Spectra', zorder=3)
        x1 = np.linspace(0,100,50)
        plt.plot(x1, x1, '-k')
    plt.title(title_list[i] + ' ' + method_list[i], loc = 'left')
    plt.xlabel('Actual (wt%)')
    plt.ylabel('Predicted (wt%)')
    if i==1:
        legend_elements1= [Line2D([0], [0], color=color[0], marker=marker[0], markeredgecolor='k', alpha=1, markersize = 12, lw=0, label='Nitrate'),
                            Line2D([0], [0], color=color[1], marker=marker[1], markeredgecolor='k', alpha=1, markersize = 12, lw=0, label='Nitrite'),
                            Line2D([0], [0], color=color[2], marker=marker[2], markeredgecolor='k', alpha=1,  markersize = 12, lw=0, label='Sulfate'),
                            Line2D([0], [0], color=color[3], marker=marker[3], markeredgecolor='k', alpha=1,  markersize = 12, lw=0, label='Borate')]
        plt.legend(handles=legend_elements1, frameon=False, bbox_to_anchor=(1,1.05), loc='upper left')
    # plt.text(1,8,r'RMSE: ' + str(round(np.mean(rmse_process_ir_normal_list[i]), 3)))
    plt.text(0.4,9.5,r'RMSE: ' + str(f'{rmse_ir_list[i][0]:.3f}'))
plt.subplots_adjust(wspace=.50,hspace=.50)
if save == True:
    plt.savefig(save_folder_pdf / ('ATR-FTIR Quantification' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('ATR-FTIR Quantification' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('ATR-FTIR Quantification' + '.eps'), bbox_inches='tight')

"""
Calculating Confidence Region
"""
def fraction_in_k_std_devs(k, n):
    return chi2.cdf(k**2, df=n)

def radius_for_fraction(alpha, n):
    chi2_val = chi2.ppf(alpha, df=n)
    return np.sqrt(chi2_val)

fraction_ellipse = fraction_in_k_std_devs(3,2)

"""
Hotelling T^2 vs. Q-Statistic with Computational Gibbsite Removal (No Yellow Points)
"""
x = T_sum[f_train].reshape(-1)
y = Q[f_train].reshape(-1)
data = np.vstack([x, y])
mean = np.mean(data, axis=1)
cov = np.cov(data)
eigvals, eigvecs = np.linalg.eigh(cov)
angle = np.degrees(np.arctan2(*eigvecs[:, 0][::-1]))
p = fraction_ellipse
threshold = chi2.ppf(fraction_ellipse, df=2)
r2 = -2 * np.log(1 - p)
r = np.sqrt(r2)
width, height = 2 * r * np.sqrt(eigvals)
ellipse3 = Ellipse(xy=mean, width=width, height=height, angle=angle,
                  edgecolor='k', fc=color0, lw=1, alpha = 1)

## Identifying faulty data
data_all = np.vstack([T_sum.reshape(-1), Q.reshape(-1)])
mean_2d = mean.reshape(2,1)
cov_inv = np.linalg.inv(cov)
diff = data_all - mean_2d
D2 = np.zeros(np.shape(T_sum.reshape(-1)))
for i in range(len(T_sum)):   
    D2[i] = diff[:,i].T @ cov_inv @ diff[:,i]
fault_array_pred = (D2 > threshold).astype(int)

## Confusion Matrix
cm1 = confusion_matrix(fault_array_true_all, fault_array_pred, labels=[0, 1])
cm2 = confusion_matrix(fault_array_true_all[f_test_not_conc], fault_array_pred[f_test_not_conc], labels=[0,1])

## All data including model-based faults
plt.figure(figsize=(8, 6))
sns.heatmap(cm1, annot=True, fmt="d", cmap="Blues", xticklabels=['Normal', 'Faulty'], yticklabels=['Normal', 'Faulty'], vmin=0, vmax = 14)
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.text(1.2, 0.2, 'Type I Errors')
plt.text(0.2, 1.2, 'Type II Errors')
if save == True:
    plt.savefig(save_folder_pdf / ('Confusion Matrix + Model' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Confusion Matrix + Model' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Confusion Matrix + Model' + '.eps'), bbox_inches='tight')

list_incorrect_savgol_ram = [24, 25, 21] ## 21 is on the edge of too high Q-statistic (FBRM)
plt.figure(figsize=(6,4.5))
plt.plot(T_sum[f_train], Q[f_train], linewidth = 0, color=color[1], marker=marker[0], label = "Validation")
plt.plot(T_sum[f_test], Q[f_test], linewidth = 0, color=color[1], marker=marker[9], label = "Test")
plt.plot(T_sum[f_sensor], Q[f_sensor], linewidth = 0, color=color[0], marker=marker[1], label = "Sensor")
plt.plot(T_sum[f_carbonate], Q[f_carbonate], linewidth = 0, color=color[0], marker=marker[5], label = "Carbonate")
plt.plot(T_sum[f_zircon], Q[f_zircon], linewidth = 0, color=color[0], marker=marker[6], label = "Zircon")
plt.plot(T_sum[f_mix], Q[f_mix], linewidth = 0, color=color[0], marker=marker[7], label = "Stirrer Failure")
plt.plot(T_sum[f_pH], Q[f_pH], linewidth = 0, color=color[0], marker=marker[8], label = "pH")
plt.xlabel(r'Hotelling T$^{2}$')
plt.ylabel('SPE')
plt.xscale('log')
plt.yscale('log')
plt.legend(bbox_to_anchor=(1,1.05), loc='upper left', frameon=False)
ax = plt.gca()
ax.add_patch(ellipse3)
if save == True:
    plt.savefig(save_folder_pdf / ('Fault Detection' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Fault Detection' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Fault Detection' + '.eps'), bbox_inches='tight')


"""
Hotelling T^2 vs. Q-Statistic No Gibbsite Subtraction
"""
x_orig = T_sum_orig[f_train].reshape(-1)
y_orig = Q_orig[f_train].reshape(-1)
data_orig = np.vstack([x_orig, y_orig])
mean_orig = np.mean(data_orig, axis=1)
cov_orig = np.cov(data_orig)
eigvals_orig, eigvecs_orig = np.linalg.eigh(cov_orig)
angle_orig = np.degrees(np.arctan2(*eigvecs_orig[:, 0][::-1]))
p_orig = fraction_ellipse
threshold_orig = chi2.ppf(fraction_ellipse, df=2)
r2_orig = -2 * np.log(1 - p_orig)
r_orig = np.sqrt(r2_orig)
width_orig, height_orig = 2 * r_orig * np.sqrt(eigvals_orig)
ellipse_orig = Ellipse(xy=mean_orig, width=width_orig, height=height_orig, angle=angle_orig,
                  edgecolor='k', fc=color0, lw=1, alpha = 1)

## No Non-target removal (Orig) accuracy scores
data_orig = np.vstack([T_sum_orig.reshape(-1), Q_orig.reshape(-1)])
mean_2d = mean.reshape(2,1)
cov_inv = np.linalg.inv(cov)
diff = data_orig - mean_2d
D2 = np.zeros(np.shape(T_sum_orig.reshape(-1)))
for i in range(len(T_sum)):   
    D2[i] = diff[:,i].T @ cov_inv @ diff[:,i]
fault_array_pred_orig = (D2 > threshold).astype(int)

## Identifying faulty data
data_all_orig = np.vstack([T_sum_orig.reshape(-1), Q_orig.reshape(-1)])
mean_2d_orig = mean_orig.reshape(2,1)
cov_inv_orig = np.linalg.inv(cov_orig)
diff_orig = data_all_orig - mean_2d_orig
D2_orig = np.zeros(np.shape(T_sum_orig.reshape(-1)))
for i in range(len(T_sum_orig)):   
    D2_orig[i] = diff_orig[:,i].T @ cov_inv_orig @ diff_orig[:,i]
fault_array_pred_orig = (D2_orig> threshold_orig).astype(int)

plt.figure(figsize=(6,4.5))
plt.plot(T_sum_orig[f_train], Q_orig[f_train], linewidth = 0, color=color[1], marker=marker[0], label = "Validation")
plt.plot(T_sum_orig[f_test], Q_orig[f_test], linewidth = 0, color=color[1], marker=marker[9], label = "Test")
plt.plot(T_sum_orig[f_heel], Q_orig[f_heel], linewidth = 0, color=color[2], marker=marker[2], label = "Heel")
plt.plot(T_sum_orig[f_boricfeed], Q_orig[f_boricfeed], linewidth = 0, color=color[2], marker=marker[3], label = "Boric Feed")
plt.plot(T_sum_orig[f_gfc], Q_orig[f_gfc], linewidth = 0, color=color[2], marker=marker[4], label = "Incorrect GFC")
plt.plot(T_sum_orig[f_sensor], Q_orig[f_sensor], linewidth = 0, color=color[0], marker=marker[1], label = "Sensor")
plt.plot(T_sum_orig[f_carbonate], Q_orig[f_carbonate], linewidth = 0, color=color[0], marker=marker[5], label = "Carbonate")
plt.plot(T_sum_orig[f_zircon], Q_orig[f_zircon], linewidth = 0, color=color[0], marker=marker[6], label = "Zircon")
plt.plot(T_sum_orig[f_mix], Q_orig[f_mix], linewidth = 0, color=color[0], marker=marker[7], label = "Stirrer Failure")
plt.plot(T_sum_orig[f_pH], Q_orig[f_pH], linewidth = 0, color=color[0], marker=marker[8], label = "pH")
plt.xlabel(r'Hotelling T$^{2}$')
plt.ylabel('SPE')
plt.xscale('log')
plt.yscale('log')
plt.legend(bbox_to_anchor=(1,1.05), loc='upper left', frameon=False)
ax = plt.gca()
ax.add_patch(ellipse_orig)
if save == True:
    plt.savefig(save_folder_pdf / ('Fault Detection Original' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Fault Detection Original' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Fault Detection Original' + '.eps'), bbox_inches='tight')

"""
Hotelling T^2 vs. Q-Statistic with gibbsite subtraction
"""

x = T_sum[f_train].reshape(-1)
y = Q[f_train].reshape(-1)
data = np.vstack([x, y])
mean = np.mean(data, axis=1)
cov = np.cov(data)
eigvals, eigvecs = np.linalg.eigh(cov)
angle = np.degrees(np.arctan2(*eigvecs[:, 0][::-1]))
p = fraction_ellipse
threshold = chi2.ppf(fraction_ellipse, df=2)
r2 = -2 * np.log(1 - p)
r = np.sqrt(r2)
width, height = 2 * r * np.sqrt(eigvals)
ellipse9 = Ellipse(xy=mean, width=width, height=height, angle=angle,
                  edgecolor='k', fc=color0, lw=1, alpha = 1)

plt.figure(figsize=(6,4.5))
plt.plot(T_sum[f_train], Q[f_train], linewidth = 0, color=color[1], marker=marker[0], label = "Validation")
plt.plot(T_sum[f_test], Q[f_test], linewidth = 0, color=color[1], marker=marker[9], label = "Test")
plt.plot(T_sum[f_heel], Q[f_heel], linewidth = 0, color=color[2], marker=marker[2], label = "Heel")
plt.plot(T_sum[f_boricfeed], Q[f_boricfeed], linewidth = 0, color=color[2], marker=marker[3], label = "Boric Feed")
plt.plot(T_sum[f_gfc], Q[f_gfc], linewidth = 0, color=color[2], marker=marker[4], label = "Incorrect GFC")
plt.plot(T_sum[f_sensor], Q[f_sensor], linewidth = 0, color=color[0], marker=marker[1], label = "Sensor")
plt.plot(T_sum[f_carbonate], Q[f_carbonate], linewidth = 0, color=color[0], marker=marker[5], label = "Carbonate")
plt.plot(T_sum[f_zircon], Q[f_zircon], linewidth = 0, color=color[0], marker=marker[6], label = "Zircon")
plt.plot(T_sum[f_mix], Q[f_mix], linewidth = 0, color=color[0], marker=marker[7], label = "Stirrer Failure")
plt.plot(T_sum[f_pH], Q[f_pH], linewidth = 0, color=color[0], marker=marker[8], label = "pH")
plt.xlabel(r'Hotelling T$^{2}$')
plt.ylabel('SPE')
plt.xscale('log')
plt.yscale('log')
plt.legend(bbox_to_anchor=(1,1.05), loc='upper left', frameon=False)
ax = plt.gca()
ax.add_patch(ellipse9)
if save == True:
    plt.savefig(save_folder_pdf / ('Fault Detection Model Errors' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Fault Detection Model Errors' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Fault Detection Model Errors' + '.eps'), bbox_inches='tight')

"""
Primary Publication Figure
"""

x = T_sum[f_train].reshape(-1)
y = Q[f_train].reshape(-1)
data = np.vstack([x, y])
mean = np.mean(data, axis=1)
cov = np.cov(data)
eigvals, eigvecs = np.linalg.eigh(cov)
angle = np.degrees(np.arctan2(*eigvecs[:, 0][::-1]))
p = fraction_ellipse
threshold = chi2.ppf(fraction_ellipse, df=2)
r2 = -2 * np.log(1 - p)
r = np.sqrt(r2)
width, height = 2 * r * np.sqrt(eigvals)
ellipse9_com = Ellipse(xy=mean, width=width, height=height, angle=angle,
                  edgecolor='k', fc=color0, lw=1, alpha = 1)

x_orig = T_sum_orig[f_train].reshape(-1)
y_orig = Q_orig[f_train].reshape(-1)
data_orig = np.vstack([x_orig, y_orig])
mean_orig = np.mean(data_orig, axis=1)
cov_orig = np.cov(data_orig)
eigvals_orig, eigvecs_orig = np.linalg.eigh(cov_orig)
angle_orig = np.degrees(np.arctan2(*eigvecs_orig[:, 0][::-1]))
p_orig = fraction_ellipse
threshold_orig = chi2.ppf(fraction_ellipse, df=2)
r2_orig = -2 * np.log(1 - p_orig)
r_orig = np.sqrt(r2_orig)
width_orig, height_orig = 2 * r_orig * np.sqrt(eigvals_orig)
ellipse_orig_com = Ellipse(xy=mean_orig, width=width_orig, height=height_orig, angle=angle_orig,
                  edgecolor='k', fc=color0, lw=1, alpha = 1)

plt.figure(figsize=(10,4))
plt.subplot(1,2,1)
plt.plot(T_sum[f_train], Q[f_train], linewidth = 0, color=color[1], marker=marker[0], label = "Validation")
plt.plot(T_sum[f_test], Q[f_test], linewidth = 0, color=color[1], marker=marker[9], label = "Test")
plt.plot(T_sum[f_heel], Q[f_heel], linewidth = 0, color=color[2], marker=marker[2], label = "Heel")
plt.plot(T_sum[f_boricfeed], Q[f_boricfeed], linewidth = 0, color=color[2], marker=marker[3], label = "Boric Feed")
plt.plot(T_sum[f_gfc], Q[f_gfc], linewidth = 0, color=color[2], marker=marker[4], label = "Incorrect GFC")
plt.plot(T_sum[f_sensor], Q[f_sensor], linewidth = 0, color=color[0], marker=marker[1], label = "Sensor")
plt.plot(T_sum[f_carbonate], Q[f_carbonate], linewidth = 0, color=color[0], marker=marker[5], label = "Carbonate")
plt.plot(T_sum[f_zircon], Q[f_zircon], linewidth = 0, color=color[0], marker=marker[6], label = "Zircon")
plt.plot(T_sum[f_mix], Q[f_mix], linewidth = 0, color=color[0], marker=marker[7], label = "Stirrer Failure")
plt.plot(T_sum[f_pH], Q[f_pH], linewidth = 0, color=color[0], marker=marker[8], label = "pH")
plt.xlabel(r'Hotelling T$^{2}$')
plt.ylabel('SPE')
plt.title('a)', loc='left', fontweight='bold')
plt.xscale('log')
plt.yscale('log')
plt.xlim((0.8, 1000))
plt.ylim((100, 2e6))
ax = plt.gca()
ax.add_patch(ellipse9_com)
plt.subplot(1,2,2)
plt.plot(T_sum_orig[f_train], Q_orig[f_train], linewidth = 0, color=color[1], marker=marker[0], label = "Validation")
plt.plot(T_sum_orig[f_test], Q_orig[f_test], linewidth = 0, color=color[1], marker=marker[9], label = "Test")
plt.plot(T_sum_orig[f_heel], Q_orig[f_heel], linewidth = 0, color=color[2], marker=marker[2], label = "Heel")
plt.plot(T_sum_orig[f_boricfeed], Q_orig[f_boricfeed], linewidth = 0, color=color[2], marker=marker[3], label = "Boric Feed")
plt.plot(T_sum_orig[f_gfc], Q_orig[f_gfc], linewidth = 0, color=color[2], marker=marker[4], label = "Incorrect GFC")
plt.plot(T_sum_orig[f_sensor], Q_orig[f_sensor], linewidth = 0, color=color[0], marker=marker[1], label = "Sensor")
plt.plot(T_sum_orig[f_carbonate], Q_orig[f_carbonate], linewidth = 0, color=color[0], marker=marker[5], label = "Carbonate")
plt.plot(T_sum_orig[f_zircon], Q_orig[f_zircon], linewidth = 0, color=color[0], marker=marker[6], label = "Zircon")
plt.plot(T_sum_orig[f_mix], Q_orig[f_mix], linewidth = 0, color=color[0], marker=marker[7], label = "Stirrer Failure")
plt.plot(T_sum_orig[f_pH], Q_orig[f_pH], linewidth = 0, color=color[0], marker=marker[8], label = "pH")
plt.xlabel(r'Hotelling T$^{2}$')
plt.ylabel('SPE')
plt.title('b)', loc='left', fontweight='bold')
plt.xscale('log')
plt.yscale('log')
plt.xlim((0.8, 1000))
plt.ylim((100, 2e6))
plt.legend(bbox_to_anchor=(1,1.05), loc='upper left', frameon=False)
ax = plt.gca()
ax.add_patch(ellipse_orig_com)
plt.subplots_adjust(wspace=.50,hspace=.70)
if save == True:
    plt.savefig(save_folder_pdf / ('Fault Detection Combined' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Fault Detection Combined' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Fault Detection Combined' + '.eps'), bbox_inches='tight')



    
"""
Hotelling T^2 vs. Q-Statistic with Gibbsite subtraction AND using training data
"""

x = np.hstack((T_sum_acttrain,T_sum[f_train])).reshape(-1)
y = np.vstack((Q_acttrain,Q[f_train])).reshape(-1)
data = np.vstack([x, y])
mean = np.mean(data, axis=1)
cov = np.cov(data)
eigvals, eigvecs = np.linalg.eigh(cov)
angle = np.degrees(np.arctan2(*eigvecs[:, 0][::-1]))
p = fraction_ellipse
threshold = chi2.ppf(fraction_ellipse, df=2)
r2 = -2 * np.log(1 - p)
r = np.sqrt(r2)
width, height = 2 * r * np.sqrt(eigvals)
ellipse91 = Ellipse(xy=mean, width=width, height=height, angle=angle,
                  edgecolor='k', fc=color0, lw=1, alpha = 1)

plt.figure(figsize=(6,4.5))
plt.plot(T_sum_acttrain, Q_acttrain, linewidth = 0, color='k', marker = marker[0], label = 'Train')
plt.plot(T_sum[f_train], Q[f_train], linewidth = 0, color=color[1], marker=marker[0], label = "Validation")
plt.plot(T_sum[f_test], Q[f_test], linewidth = 0, color=color[1], marker=marker[9], label = "Test")
plt.plot(T_sum[f_heel], Q[f_heel], linewidth = 0, color=color[2], marker=marker[2], label = "Heel")
plt.plot(T_sum[f_boricfeed], Q[f_boricfeed], linewidth = 0, color=color[2], marker=marker[3], label = "Boric Feed")
plt.plot(T_sum[f_gfc], Q[f_gfc], linewidth = 0, color=color[2], marker=marker[4], label = "Incorrect GFC")
plt.plot(T_sum[f_sensor], Q[f_sensor], linewidth = 0, color=color[0], marker=marker[1], label = "Sensor")
plt.plot(T_sum[f_carbonate], Q[f_carbonate], linewidth = 0, color=color[0], marker=marker[5], label = "Carbonate")
plt.plot(T_sum[f_zircon], Q[f_zircon], linewidth = 0, color=color[0], marker=marker[6], label = "Zircon")
plt.plot(T_sum[f_mix], Q[f_mix], linewidth = 0, color=color[0], marker=marker[7], label = "Stirrer Failure")
plt.plot(T_sum[f_pH], Q[f_pH], linewidth = 0, color=color[0], marker=marker[8], label = "pH")
plt.xlabel(r'Hotelling T$^{2}$')
plt.ylabel('SPE')
plt.xscale('log')
plt.yscale('log')
plt.legend(bbox_to_anchor=(1,1.05), loc='upper left', frameon=False)
ax = plt.gca()
ax.add_patch(ellipse91)
if save == True:
    plt.savefig(save_folder_pdf / ('Fault Detection Model Errors + Train' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Fault Detection Model Errors + Train' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Fault Detection Model Errors + Train' + '.eps'), bbox_inches='tight')


"""
Hotelling T^2 vs. Q-Statistic with Single Instruments
"""

## Raman ellipse
x = T_sum_ram[f_train].reshape(-1)
y = Q_ram[f_train].reshape(-1)
data = np.vstack([x, y])
mean = np.mean(data, axis=1)
cov = np.cov(data)
eigvals, eigvecs = np.linalg.eigh(cov)
angle = np.degrees(np.arctan2(*eigvecs[:, 0][::-1]))
p = fraction_ellipse
threshold = chi2.ppf(fraction_ellipse, df=2)
r2 = -2 * np.log(1 - p)
r = np.sqrt(r2)
width, height = 2 * r * np.sqrt(eigvals)
ellipse9_ram = Ellipse(xy=mean, width=width, height=height, angle=angle,
                  edgecolor='k', fc=color0, lw=1, alpha = 1)

## Raman accuracy scores
data_ram = np.vstack([T_sum_ram.reshape(-1), Q_ram.reshape(-1)])
mean_2d = mean.reshape(2,1)
cov_inv = np.linalg.inv(cov)
diff = data_ram - mean_2d
D2 = np.zeros(np.shape(T_sum_ram.reshape(-1)))
for i in range(len(T_sum)):   
    D2[i] = diff[:,i].T @ cov_inv @ diff[:,i]
fault_array_pred_ram = (D2 > threshold).astype(int)

## IR ellipse
x = T_sum_ir[f_train].reshape(-1)
y = Q_ir[f_train].reshape(-1)
data = np.vstack([x, y])
mean = np.mean(data, axis=1)
cov = np.cov(data)
eigvals, eigvecs = np.linalg.eigh(cov)
angle = np.degrees(np.arctan2(*eigvecs[:, 0][::-1]))
p = fraction_ellipse
threshold = chi2.ppf(fraction_ellipse, df=2)
r2 = -2 * np.log(1 - p)
r = np.sqrt(r2)
width, height = 2 * r * np.sqrt(eigvals)
ellipse9_ir = Ellipse(xy=mean, width=width, height=height, angle=angle,
                  edgecolor='k', fc=color0, lw=1, alpha = 1)

## IR accuracy scores
data_ir = np.vstack([T_sum_ir.reshape(-1), Q_ir.reshape(-1)])
mean_2d = mean.reshape(2,1)
cov_inv = np.linalg.inv(cov)
diff = data_ir - mean_2d
D2 = np.zeros(np.shape(T_sum_ir.reshape(-1)))
for i in range(len(T_sum)):   
    D2[i] = diff[:,i].T @ cov_inv @ diff[:,i]
fault_array_pred_ir = (D2 > threshold).astype(int)

## FBRM ellipse
x = T_sum_fbrm[f_train].reshape(-1)
y = Q_fbrm[f_train].reshape(-1)
data = np.vstack([x, y])
mean = np.mean(data, axis=1)
cov = np.cov(data)
eigvals, eigvecs = np.linalg.eigh(cov)
angle = np.degrees(np.arctan2(*eigvecs[:, 0][::-1]))
p = fraction_ellipse
threshold = chi2.ppf(fraction_ellipse, df=2)
r2 = -2 * np.log(1 - p)
r = np.sqrt(r2)
width, height = 2 * r * np.sqrt(eigvals)
ellipse9_fbrm = Ellipse(xy=mean, width=width, height=height, angle=angle,
                  edgecolor='k', fc=color0, lw=1, alpha = 1)

## FBRM accuracy scores
data_fbrm = np.vstack([T_sum_fbrm.reshape(-1), Q_fbrm.reshape(-1)])
mean_2d = mean.reshape(2,1)
cov_inv = np.linalg.inv(cov)
diff = data_fbrm - mean_2d
D2 = np.zeros(np.shape(T_sum_fbrm.reshape(-1)))
for i in range(len(T_sum)):   
    D2[i] = diff[:,i].T @ cov_inv @ diff[:,i]
fault_array_pred_fbrm = (D2 > threshold).astype(int)


plt.figure(figsize=(9,7))

plt.subplot(2,2,1)
plt.plot(T_sum_ram[f_train], Q_ram[f_train], linewidth = 0, color=color[1], marker=marker[0], label = "Validation")
plt.plot(T_sum_ram[f_test], Q_ram[f_test], linewidth = 0, color=color[1], marker=marker[9], label = "Test")
plt.plot(T_sum_ram[f_heel], Q_ram[f_heel], linewidth = 0, color=color[2], marker=marker[2], label = "Heel")
plt.plot(T_sum_ram[f_boricfeed], Q_ram[f_boricfeed], linewidth = 0, color=color[2], marker=marker[3], label = "Boric Feed")
plt.plot(T_sum_ram[f_gfc], Q_ram[f_gfc], linewidth = 0, color=color[2], marker=marker[4], label = "Incorrect GFC")
plt.plot(T_sum_ram[f_sensor], Q_ram[f_sensor], linewidth = 0, color=color[0], marker=marker[1], label = "Sensor")
plt.plot(T_sum_ram[f_carbonate], Q_ram[f_carbonate], linewidth = 0, color=color[0], marker=marker[5], label = "Carbonate")
plt.plot(T_sum_ram[f_zircon], Q_ram[f_zircon], linewidth = 0, color=color[0], marker=marker[6], label = "Zircon")
plt.plot(T_sum_ram[f_mix], Q_ram[f_mix], linewidth = 0, color=color[0], marker=marker[7], label = "Stirrer Failure")
plt.plot(T_sum_ram[f_pH], Q_ram[f_pH], linewidth = 0, color=color[0], marker=marker[8], label = "pH")
plt.xlabel(r'Hotelling T$^{2}$')
plt.ylabel('SPE')
plt.title('a) Raman', loc='left', fontsize=20)
plt.xscale('log')
plt.yscale('log')
ax = plt.gca()
ax.add_patch(ellipse9_ram)

plt.subplot(2,2,2)
plt.plot(T_sum_ir[f_train], Q_ir[f_train], linewidth = 0, color=color[1], marker=marker[0], label = "Validation")
plt.plot(T_sum_ir[f_test], Q_ir[f_test], linewidth = 0, color=color[1], marker=marker[9], label = "Test")
plt.plot(T_sum_ir[f_heel], Q_ir[f_heel], linewidth = 0, color=color[2], marker=marker[2], label = "Heel")
plt.plot(T_sum_ir[f_boricfeed], Q_ir[f_boricfeed], linewidth = 0, color=color[2], marker=marker[3], label = "Boric Feed")
plt.plot(T_sum_ir[f_gfc], Q_ir[f_gfc], linewidth = 0, color=color[2], marker=marker[4], label = "Incorrect GFC")
plt.plot(T_sum_ir[f_sensor], Q_ir[f_sensor], linewidth = 0, color=color[0], marker=marker[1], label = "Sensor")
plt.plot(T_sum_ir[f_carbonate], Q_ir[f_carbonate], linewidth = 0, color=color[0], marker=marker[5], label = "Carbonate")
plt.plot(T_sum_ir[f_zircon], Q_ir[f_zircon], linewidth = 0, color=color[0], marker=marker[6], label = "Zircon")
plt.plot(T_sum_ir[f_mix], Q_ir[f_mix], linewidth = 0, color=color[0], marker=marker[7], label = "Stirrer Failure")
plt.plot(T_sum_ir[f_pH], Q_ir[f_pH], linewidth = 0, color=color[0], marker=marker[8], label = "pH")
plt.xlabel(r'Hotelling T$^{2}$')
plt.ylabel('SPE')
plt.title('b) ATR-FTIR', loc='left', fontsize=20)
plt.xscale('log')
plt.yscale('log')
ax = plt.gca()
ax.add_patch(ellipse9_ir)

plt.subplot(2,2,3)
plt.plot(T_sum_fbrm[f_train], Q_fbrm[f_train], linewidth = 0, color=color[1], marker=marker[0], label = "Validation")
plt.plot(T_sum_fbrm[f_test], Q_fbrm[f_test], linewidth = 0, color=color[1], marker=marker[9], label = "Test")
plt.plot(T_sum_fbrm[f_heel], Q_fbrm[f_heel], linewidth = 0, color=color[2], marker=marker[2], label = "Heel")
plt.plot(T_sum_fbrm[f_boricfeed], Q_fbrm[f_boricfeed], linewidth = 0, color=color[2], marker=marker[3], label = "Boric Feed")
plt.plot(T_sum_fbrm[f_gfc], Q_fbrm[f_gfc], linewidth = 0, color=color[2], marker=marker[4], label = "Incorrect GFC")
plt.plot(T_sum_fbrm[f_sensor], Q_fbrm[f_sensor], linewidth = 0, color=color[0], marker=marker[1], label = "Sensor")
plt.plot(T_sum_fbrm[f_carbonate], Q_fbrm[f_carbonate], linewidth = 0, color=color[0], marker=marker[5], label = "Carbonate")
plt.plot(T_sum_fbrm[f_zircon], Q_fbrm[f_zircon], linewidth = 0, color=color[0], marker=marker[6], label = "Zircon")
plt.plot(T_sum_fbrm[f_mix], Q_fbrm[f_mix], linewidth = 0, color=color[0], marker=marker[7], label = "Stirrer Failure")
plt.plot(T_sum_fbrm[f_pH], Q_fbrm[f_pH], linewidth = 0, color=color[0], marker=marker[8], label = "pH")
plt.xlabel(r'Hotelling T$^{2}$')
plt.ylabel('SPE')
plt.title('c) FBRM', loc='left', fontsize=20)
plt.xscale('log')
plt.yscale('log')
plt.legend(bbox_to_anchor=(1.3,1.20), loc='upper left', frameon=False)
ax = plt.gca()
ax.add_patch(ellipse9_fbrm)

plt.subplots_adjust(wspace=.50,hspace=.70)

if save == True:
    plt.savefig(save_folder_pdf / ('Fault Detection - Individual Instruments' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Fault Detection - Individual Instruments' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Fault Detection - Individual Instruments' + '.eps'), bbox_inches='tight')


"""
Confusion Matrices of Single Instruments
"""

## Confusion Matrix
cm_ram = confusion_matrix(fault_array_true_all, fault_array_pred_ram, labels=[0,1])
cm_ir = confusion_matrix(fault_array_true_all, fault_array_pred_ir, labels=[0,1])
cm_fbrm = confusion_matrix(fault_array_true_all, fault_array_pred_fbrm, labels=[0,1])
cm_orig = confusion_matrix(fault_array_true_all, fault_array_pred_orig, labels=[0,1])

fig, axes = plt.subplots(2, 2, figsize=(10, 10))
ax1, ax2, ax3, ax4 = axes.flatten()
##   [left, bottom, width, height] in figure coords (0–1)
cbar_ax = fig.add_axes([1.02, 0.09, 0.03, 0.85])
sns.heatmap(cm1, annot=True, fmt="d", cmap="Reds", xticklabels=['Normal', 'Faulty'], yticklabels=['Normal', 'Faulty'], ax=ax1, vmin=0, vmax = 16, cbar=False)
ax1.set_xlabel('Predicted')
ax1.set_ylabel('Actual')
ax1.set_title('a) Data Fusion', loc = 'left')

sns.heatmap(cm_ram, annot=True, fmt="d", cmap="Reds", xticklabels=['Normal', 'Faulty'], yticklabels=['Normal', 'Faulty'], ax=ax2, vmin=0, vmax=16, cbar=True, cbar_ax = cbar_ax)
ax2.set_title('b) Raman', loc = 'left')
ax2.set_xlabel('Predicted')
ax2.set_ylabel('Actual')

sns.heatmap(cm_ir, annot=True, fmt='d', cmap='Reds', xticklabels=['Normal', 'Faulty'], yticklabels=['Normal', 'Faulty'], ax=ax3, vmin=0, vmax=16, cbar=False)
ax3.set_title('c) ATR-FTIR', loc = 'left')
ax3.set_xlabel('Predicted')
ax3.set_ylabel('Actual')

sns.heatmap(cm_fbrm, annot=True, fmt='d', cmap='Reds', xticklabels=['Normal', 'Faulty'], yticklabels=['Normal', 'Faulty'], ax=ax4, vmin=0, vmax=16, cbar=False)
ax4.set_title('d) FBRM', loc = 'left')
ax4.set_xlabel('Predicted')
ax4.set_ylabel('Actual')
plt.tight_layout()
if save == True:
    plt.savefig(save_folder_pdf / ('Confusion Matrices - Individual Instruments' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Confusion Matrices - Individual Instruments' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Confusion Matrices - Individual Instruments' + '.eps'), bbox_inches='tight')

"""
Accuracy Scores - All Methods
"""
## All
tn_all, fp_all, fn_all, tp_all = cm1.ravel()
## Raman
tn_ram, fp_ram, fn_ram, tp_ram = cm_ram.ravel()
## ATR-FTIR
tn_ir,  fp_ir,  fn_ir,  tp_ir  = cm_ir.ravel()
## FBRM
tn_fbrm, fp_fbrm, fn_fbrm, tp_fbrm = cm_fbrm.ravel()
## No fault detection
tn_orig, fp_orig, fn_orig, tp_orig = cm_orig.ravel()

TN = np.array([tn_all, tn_ram, tn_ir, tn_fbrm, tn_orig])
FP = np.array([fp_all, fp_ram, fp_ir, fp_fbrm, fp_orig])
FN = np.array([fn_all, fn_ram, fn_ir, fn_fbrm, fn_orig])
TP = np.array([tp_all, tp_ram, tp_ir, tp_fbrm, tp_orig])

met_Accuracy = (TP + TN) / (TP + TN + FP + FN)
met_Precision = (TP) / (TP + FP)
met_Recall = (TP) / (TP + FN)
met_F1_score = (2 * TP) / (2 * TP + FP + FN)





