# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 19:02:09 2024

@author: scrouse6
"""

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
import os
import os, platform, io
from pathlib import Path
path = Path(__file__).resolve().parent
    
from Functions import *

save_folder_pdf = path / 'Figures/PDF/'
save_folder_jpg = path / 'Figures/JPG/'
save_folder_eps = path / 'Figures/EPS/'
save = True


"""
Plotting Standardization
"""

mpl.rcParams['font.family'] = 'Times New Roman'
plt.rcParams.update({'font.size': 20})
mpl.rcParams['figure.dpi'] = 300
color=['royalblue','orangered','goldenrod','limegreen','darkviolet','slategray','chocolate','turquoise','dodgerblue','deeppink','seagreen']
marker=['o','^','s','*','D','X']

"""
Loading Boric Acid Data
"""

directory = path / 'Raw Data/Other/'
filenames = ['Boric acid calib in water 29102021 IR', 'Boric acid calib 3M NaOH 29102021 IR']
for i in range(2):
    filenames[i] = directory / (filenames[i] + '.spc')
X, wavenumber = spc_read(filenames)
X_water = X[0][-2,:] - X[0][5,:]
X_naoh = X[1][-2,:] - X[1][5,:]

"""
Plotting Boric Acid
"""
plt.figure()
plt.plot(wavenumber, X_water.T, color=color[0], label='Water')
plt.plot(wavenumber, X_naoh.T, color=color[2], linestyle='-.', label='3 m NaOH')
plt.legend(bbox_to_anchor=(1,1.05), loc='upper left', title = '2.4 m Boric acid in:')
plt.xlim((700, 1600))
plt.text(985, 0.50, '936')
plt.text(1365, 0.40, '1406')
plt.xlabel(r'Wavenumber (cm$^{-1}$)')
plt.ylabel('Aborbance (A. U.)')
if save == True:
    plt.savefig(save_folder_pdf / ('Boric Acid Reference' + '.pdf'), bbox_inches='tight')
    plt.savefig(save_folder_jpg / ('Boric Acid Reference' + '.jpg'), bbox_inches='tight')
    plt.savefig(save_folder_eps / ('Boric Acid Reference' + '.eps'), bbox_inches='tight')








plt.show()