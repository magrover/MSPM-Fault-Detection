# -*- coding: utf-8 -*-
"""
Created on Wed Oct  9 09:52:45 2024

@author: scrouse6
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import os, platform, io
from pathlib import Path
path = Path(__file__).resolve().parent

mpl.rcParams['font.family'] = 'Times New Roman'
plt.rcParams.update({'font.size': 20})
mpl.rcParams['figure.dpi'] = 300
color=['orangered','royalblue','goldenrod','limegreen','darkviolet','slategray','chocolate','turquoise','dodgerblue','deeppink','seagreen']
marker=['o','^','s','*','D','X']

save_folder_pdf = path / 'Figures/PDF/'
save_folder_jpg = path / 'Figures/JPG/'
save_folder_eps = path / 'Figures/EPS/'
save = True


# Constants (SI Units)
g = 9.81            # Acceleration due to gravity (m/s^2)
rho_p = 2650        # Density of silica particle (kg/m^3)
rho_f = 997         # Density of water at 25°C (kg/m^3)
mu = 0.00089        # Dynamic viscosity of water at 25°C (Pa·s)
distance = 0.02     # Distance particles fall (meters)

radii = np.linspace(0.1e-6, 600e-6, 1000)  # Radii in meters

# Calculate settling velocities using Stokes' Law
velocities = (2 / 9) * (radii ** 2) * ((rho_p - rho_f) * g) / mu

times = distance / velocities

# Plotting Settling Velocity vs. Particle Radius
plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
plt.plot(radii * 1e6, velocities * 1e2, color='blue', linewidth = 3)
plt.xlim((0, radii.max() * 1e6))
plt.ylim((0, velocities.max() * 1e2))
plt.xlabel('Particle Radius (μm)')
plt.ylabel('Settling Velocity (cm/s)')
plt.title('a)', loc='left', fontweight='bold')
plt.grid(True)

# Plotting Time to Fall 5 cm vs. Particle Radius
plt.subplot(1, 2, 2)
plt.plot(radii * 1e6, times, color='green', linewidth = 3)
plt.xlim((radii.min() * 1e6, radii.max() * 1e6))
plt.ylim((times.min(), times.max()))
plt.xlabel('Particle Radius (μm)')
plt.ylabel('Time to Fall 2 cm (s)')
plt.title('b)', loc='left', fontweight='bold')
plt.yscale('log')
plt.xscale('log')
plt.grid(True)

plt.tight_layout()
plt.savefig(save_folder_pdf / ('Stokes Law' + '.pdf'), bbox_inches='tight')
plt.savefig(save_folder_jpg / ('Stokes Law' + '.jpg'), bbox_inches='tight')
plt.savefig(save_folder_eps / ('Stokes Law' + '.eps'), bbox_inches='tight')


"""
Single Velocity Calculation
"""
radius = 2.5e-6
velocity = (2 / 9) * (radius ** 2) * ((rho_p - rho_f) * g) / mu
time = distance / velocity

print('Time to travel ' + str(round(distance, 3)) + ': ' + str(round(time,3)) + 'Seconds')

plt.show()
