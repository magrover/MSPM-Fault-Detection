# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 16:31:30 2024

@author: scrouse6
"""

import numpy as np
import pandas as pd
from scipy.stats.qmc import LatinHypercube

"""
Options
"""
## Uncomment out the experiment being done at any given time
## Also need to uncomment the code itself for some experiments

## Normal Operation (1,2,3)
# n_experiments = 3
# seed = 19
# alpha_1 = 0.80  ## The fraction of material leaving tank one and going to tank two
# alpha_2 = 0.80  ## The fraction of material leaving tank two and going to tank three
# alpha_3 = 0.80  ## The fraction of material leaving tank three and going to the melter

# ## Sensor Faults (4,5)
# n_experiments = 2
# seed = 190
# alpha_1 = 0.80  ## The fraction of material leaving tank one and going to tank two
# alpha_2 = 0.80  ## The fraction of material leaving tank two and going to tank three
# alpha_3 = 0.80  ## The fraction of material leaving tank three and going to the melter

# ## Mixing Fault 1 (6)
# n_experiments = 1
# seed = 1900
# alpha_1 = 0.73  ## The fraction of material leaving tank one and going to tank two
# alpha_2 = 0.61  ## The fraction of material leaving tank two and going to tank three
# alpha_3 = 0.69  ## The fraction of material leaving tank three and going to the melter

# ## Mixing Fault 2 (7)
# n_experiments = 1
# seed = 19000
# alpha_1 = 0.92  ## The fraction of material leaving tank one and going to tank two
# alpha_2 = 0.59  ## The fraction of material leaving tank two and going to tank three
# alpha_3 = 0.76  ## The fraction of material leaving tank three and going to the melter

# ## Normal Operation (8,9)
# n_experiments = 2
# seed = 190000
# alpha_1 = 0.80  ## The fraction of material leaving tank one and going to tank two
# alpha_2 = 0.80  ## The fraction of material leaving tank two and going to tank three
# alpha_3 = 0.80  ## The fraction of material leaving tank three and going to the melter

# ## Out-of-spec Feed (10) [Not Performed]
# n_experiments = 1
# seed = 1900000
# alpha_1 = 0.80  ## The fraction of material leaving tank one and going to tank two
# alpha_2 = 0.80  ## The fraction of material leaving tank two and going to tank three
# alpha_3 = 0.80  ## The fraction of material leaving tank three and going to the melter

## Incorrect GFC Addition (11)
n_experiments = 1
seed = 19000000
alpha_1 = 0.80  ## The fraction of material leaving tank one and going to tank two
alpha_2 = 0.80  ## The fraction of material leaving tank two and going to tank three
alpha_3 = 0.80  ## The fraction of material leaving tank three and going to the melter

# # Carbonate in waste stream (12)
# n_experiments = 1
# seed = 190000000
# alpha_1 = 0.80  ## The fraction of material leaving tank one and going to tank two
# alpha_2 = 0.80  ## The fraction of material leaving tank two and going to tank three
# alpha_3 = 0.80  ## The fraction of material leaving tank three and going to the melter
# carbonate = [0.0, 0.0]

# ## Unanticipated Crystallization (13)
# n_experiments = 1
# seed = 1900000000
# alpha_1 = 0.80  ## The fraction of material leaving tank one and going to tank two
# alpha_2 = 0.80  ## The fraction of material leaving tank two and going to tank three
# alpha_3 = 0.80  ## The fraction of material leaving tank three and going to the melter





"""
Chemical Bounds (Initial)
"""
## The salts here refer to their sodium equivalents (sodium nitrate)
water = [100.0, 100.0]
hydroxide = [12.0, 12.0]
nitrate = [6.37, 17.00]
nitrite = [3.93, 8.07]
sulfate = [0.0, 2.13]
borate = [0.0, 0.0]
iron = [3.30, 23.72]
kyanite = [1.28, 8.41]
silica = [0.31, 1.97]
gibbsite = [3.29, 23.65]

bound_simulant = np.array([water, hydroxide, nitrate, nitrite, sulfate, borate, iron, kyanite, silica, gibbsite])
# ## Carbonate in waste stream (12)
# bound_simulant = np.array([water, hydroxide, nitrate, nitrite, sulfate, borate, iron, kyanite, silica, gibbsite, carbonate])

n_species = len(bound_simulant)
    
"""
GFC Bounds
"""
borate_gfc = [5.0, 13.42]
kyanite_gfc = [5.0, 15.0]
silica_gfc = [2.0, 10.0]

bound_gfc = np.array([[0,0],[0,0],[0,0],[0,0],[0,0],borate_gfc,[0,0], kyanite_gfc, silica_gfc,[0,0]])
# ## Carbonate in waste stream (12)
# bound_gfc = np.array([[0,0],[0,0],[0,0],[0,0],[0,0],borate_gfc,[0,0], kyanite_gfc, silica_gfc,[0,0],[0,0]])

n_gfc = len(bound_gfc)

"""
Chemical Bounds (After GFC Addition)
"""

bound_simulant_gfc = bound_simulant + bound_gfc


"""
Generation of Initial Simulants
"""
np.random.seed(seed)

simulant_initial_rand = np.random.rand(n_species, n_experiments)
simulant_prior_tank2_rand = np.random.rand(n_species, n_experiments)
simulant_prior_tank3_rand = np.random.rand(n_species, n_experiments)
gfc_additions_rand = np.random.rand(n_species, n_experiments)

simulant_initial = simulant_initial_rand*(bound_simulant[:,1:2]-bound_simulant[:,0:1])+bound_simulant[:,0:1]
simulant_prior_tank2 = simulant_prior_tank2_rand*(bound_simulant_gfc[:,1:2]-bound_simulant_gfc[:,0:1])+bound_simulant_gfc[:,0:1]
simulant_prior_tank3 = simulant_prior_tank3_rand*(bound_simulant_gfc[:,1:2]-bound_simulant_gfc[:,0:1])+bound_simulant_gfc[:,0:1]
gfc_additions = gfc_additions_rand*(bound_gfc[:,1:2]-bound_gfc[:,0:1])+bound_gfc[:,0:1]

# ## Out-of-spec feed (10)
# simulant_initial[2,0] = 22.5
# simulant_initial[6,0] = 0
# simulant_initial[7,0] = 0

# Incorrect GFC Addition (11)
simulant_initial[5,0] = 2.5
gfc_additions[7,0] = 0.0

# ## Carbonate in waste stream (12)
# simulant_initial[-1,0] = 5


"""
Mixing Heels
"""
Tank_1 = simulant_initial.copy()
Tank_2 = (Tank_1*alpha_1) + (simulant_prior_tank2*(1-alpha_2)) + gfc_additions
Tank_3 = (Tank_2*alpha_2) + (simulant_prior_tank3*(1-alpha_3))

"""
Reshaping
"""
Tank_1 = Tank_1.T
Tank_2 = Tank_2.T
Tank_3 = Tank_3.T

gfc_additions_T = gfc_additions.T
simulant_prior_tank2_T = simulant_prior_tank2.T
simulant_prior_tank3_T = simulant_prior_tank3.T

